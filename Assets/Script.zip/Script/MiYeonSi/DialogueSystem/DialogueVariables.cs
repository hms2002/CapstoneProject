using UnityEngine;
using Ink.Runtime;
using System.Collections.Generic;

public class DialogueVariables
{
    public Dictionary<string, Ink.Runtime.Object> variables { get; private set; }
    private Story globalVariablesStory;

    public DialogueVariables(TextAsset loadGlobalsJSON)
    {
        variables = new Dictionary<string, Ink.Runtime.Object>();

        // ������ �Ҵ���� �ʾ����� �ε带 �ǳʶݴϴ�.
        if (loadGlobalsJSON == null)
        {
            Debug.Log("���� ���� JSON�� �Ҵ���� �ʾҽ��ϴ�. (������ ����ȭ ����)");
            return;
        }

        try
        {
            globalVariablesStory = new Story(loadGlobalsJSON.text);
            foreach (string name in globalVariablesStory.variablesState)
            {
                Ink.Runtime.Object value = globalVariablesStory.variablesState.GetVariableWithName(name);
                variables.Add(name, value);
            }
        }
        catch (System.Exception e)
        {
            Debug.LogError($"Ink ���� ���� �ε� �� ���� �߻�: {e.Message}");
        }
    }

    public void StartListening(Story story)
    {
        if (story == null) return;
        VariablesToStory(story);
        story.variablesState.variableChangedEvent += VariableChanged;
    }

    public void StopListening(Story story)
    {
        if (story == null) return;
        story.variablesState.variableChangedEvent -= VariableChanged;
    }

    private void VariableChanged(string name, Ink.Runtime.Object value)
    {
        if (variables.ContainsKey(name)) variables[name] = value;
    }

    private void VariablesToStory(Story story)
    {
        foreach (KeyValuePair<string, Ink.Runtime.Object> variable in variables)
        {
            story.variablesState.SetGlobal(variable.Key, variable.Value);
        }
    }

    public void SaveVariables()
    {
        // ���� ���̺� �ý��� ���� �� ���
    }
}