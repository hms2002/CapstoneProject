using System.Collections.Generic;
using UnityEngine;

public class AffectionManager : MonoBehaviour
{
    public static AffectionManager Instance { get; private set; }

    // [수정] NPC ID별 호감도 저장 (기존 npcLevelDict -> npcAffectionDic)
    private Dictionary<int, int> npcAffectionDic = new Dictionary<int, int>();

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject); // 씬 전환 시에도 유지되도록 설정 (선택사항)
        }
        else
        {
            Destroy(gameObject);
        }
    }

    // [Ink 연동용] 현재 호감도 가져오기
    // 데이터가 없으면 기본값 0을 반환합니다.
    public int GetAffection(int npcId)
    {
        if (npcAffectionDic.ContainsKey(npcId))
        {
            return npcAffectionDic[npcId];
        }
        return 0; // 기본 호감도
    }

    // 호감도 추가 및 보상 체크
    public void AddAffection(NPCData data, int amount)
    {
        int id = data.id;
        int oldAffection = GetAffection(id);

        if (!npcAffectionDic.ContainsKey(id))
        {
            npcAffectionDic[id] = 0;
        }

        npcAffectionDic[id] += amount;
        int newAffection = npcAffectionDic[id];

        Debug.Log($"{data.npcName} 호감도 상승: {oldAffection} -> {newAffection}");

        // 호감도 단계가 오를 때 보상 지급 로직
        CheckRewards(data, oldAffection, newAffection);
    }

    private void CheckRewards(NPCData data, int fromLevel, int toLevel)
    {
        foreach (var reward in data.levelRewards)
        {
            // 예: 호감도가 5 -> 10이 되었다면, 그 사이(6,7...10)에 있는 보상을 모두 지급
            if (reward.targetLevel > fromLevel && reward.targetLevel <= toLevel)
            {
                if (reward.effect != null)
                {
                    reward.effect.Execute();
                    Debug.Log($"보상 획득: {reward.effect.effectDescription}");
                }
            }
        }
    }

    // 세이브 파일 로드 시 데이터 복구용
    public void SetAffection(int npcId, int value)
    {
        npcAffectionDic[npcId] = value;
    }
}