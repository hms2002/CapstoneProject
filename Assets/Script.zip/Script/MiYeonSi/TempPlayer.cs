using System.Collections.Generic;
using UnityEngine;

public class TempPlayer : MonoBehaviour
{
    public static TempPlayer Instance { get; private set; }

    [Header("�̵� ����")]
    [SerializeField] private float moveSpeed = 5f;

    [Header("��ȣ�ۿ� ����")]
    private readonly List<IInteractable> nearbyObjects = new();
    private IInteractable currentTarget; // ���� ���� ����� Ÿ��

    public InteractState CurrentState { get; private set; } = InteractState.Idle;

    private void Awake()
    {
        if (Instance == null) Instance = this;
    }

    private void Update()
    {
        if (CurrentState == InteractState.Talking) return;

        HandleMovement();
        HandleInteractSearch();

        // ��ȣ�ۿ� ����
        if (Input.GetKeyDown(KeyCode.F) && currentTarget != null)
        {
            currentTarget.OnPlayerInteract(this);
        }
    }

    private void HandleMovement()
    {
        float h = Input.GetAxisRaw("Horizontal");
        float v = Input.GetAxisRaw("Vertical");
        Vector3 moveDir = new Vector3(h, v, 0).normalized;
        transform.position += moveDir * moveSpeed * Time.deltaTime;
    }

    private void HandleInteractSearch()
    {
        IInteractable nearest = GetClosestInteractable();

        // �ִ� �Ÿ� Ÿ���� ����Ǿ��� �� (���̶���Ʈ ����)
        if (nearest != currentTarget)
        {
            if (currentTarget != null)
            {
                currentTarget.OnUnHighlight();
            }

            currentTarget = nearest;

            if (currentTarget != null)
            {
                currentTarget.OnHighlight();
                // ���� ������Ʈ�� GameEvents�� �ִٸ� ���⼭ ȣ�� ����
                // GameEvents.OnShowInteractKey?.Invoke(((MonoBehaviour)currentTarget).transform, currentTarget.GetInteractDescription());
            }
        }
    }

    private IInteractable GetClosestInteractable()
    {
        if (nearbyObjects.Count == 0) return null;

        float closestDist = float.MaxValue;
        IInteractable closestObj = null;

        for (int i = nearbyObjects.Count - 1; i >= 0; i--)
        {
            var obj = nearbyObjects[i];
            if (obj == null || (obj is MonoBehaviour mb && mb == null))
            {
                nearbyObjects.RemoveAt(i);
                continue;
            }

            float dist = Vector2.Distance(transform.position, ((MonoBehaviour)obj).transform.position);
            if (dist < closestDist)
            {
                if (obj.CanInteract(this))
                {
                    closestDist = dist;
                    closestObj = obj;
                }
            }
        }
        return closestObj;
    }

    #region Ʈ���� ��� ����Ʈ ���� �� Nearby/Leave ȣ��

    private void OnTriggerEnter2D(Collider2D other)
    {
        Debug.Log("�ֺ� ������Ʈ Ȯ��");
        if (other.TryGetComponent(out IInteractable interactable))
        {
            if (!nearbyObjects.Contains(interactable))
            {
                nearbyObjects.Add(interactable);
                interactable.OnPlayerNearby(); // [����] �ð��� ���̵� Ȱ��ȭ
            }
        }
    }

    private void OnTriggerExit2D(Collider2D other)
    {
        if (other.TryGetComponent(out IInteractable interactable))
        {
            if (nearbyObjects.Contains(interactable))
            {
                interactable.OnPlayerLeave(); // [����] �ð��� ���̵� ��Ȱ��ȭ

                if (currentTarget == interactable)
                {
                    currentTarget.OnUnHighlight();
                    currentTarget = null;
                }
                nearbyObjects.Remove(interactable);
            }
        }
    }

    #endregion

    public void SetInteractState(InteractState state)
    {
        CurrentState = state;

        // ��ȭ ���� �� Ÿ�� ���̶���Ʈ ���� (visualCue�� �������� ���ο� ���� OnPlayerLeave ȣ�� ����)
        if (state == InteractState.Talking && currentTarget != null)
        {
            currentTarget.OnUnHighlight();
            currentTarget = null;
        }
    }
}