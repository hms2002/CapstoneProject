using UnityEngine;
using UnityEngine.UI;
using System.Collections.Generic;
using TMPro;

public class RewardDisplayUI : MonoBehaviour
{
    public static RewardDisplayUI Instance { get; private set; }

    [Header("UI Root")]
    [SerializeField] private GameObject panelRoot;
    [SerializeField] private TextMeshProUGUI titleText;
    [SerializeField] private TextMeshProUGUI contextText;

    [Header("Slot Prefabs")]
    [SerializeField] private GameObject unlockSlotPrefab;
    [SerializeField] private GameObject effectSlotPrefab;
    [SerializeField] private Transform slotParent;

    // [핵심] 나를 열어준 사람이 남기고 간 진동벨(콜백)
    private System.Action onCloseCallback;

    private void Awake()
    {
        Instance = this;
        panelRoot.SetActive(false);
    }

    private void OnEnable() => UIManager.Instance?.RegisterUI("RewardDisplay");
    private void OnDisable() => UIManager.Instance?.UnregisterUI("RewardDisplay");

    // [수정] 콜백(callback) 매개변수 추가
    public void ShowReward(List<UpgradeEffectSO> uEffects = null, List<AffectionEffect> aEffects = null, System.Action callback = null)
    {
        this.onCloseCallback = callback; // 콜백 저장

        foreach (Transform child in slotParent) Destroy(child.gameObject);
        string summary = "";

        if (uEffects != null && uEffects.Count > 0)
        {
            titleText.text = "업그레이드 완료!";
            foreach (var e in uEffects) ProcessUpgrade(e, ref summary);
        }
        else if (aEffects != null && aEffects.Count > 0)
        {
            titleText.text = "호감도 보상!";
            foreach (var e in aEffects) ProcessAffection(e, ref summary);
        }

        contextText.text = summary.TrimEnd();
        panelRoot.SetActive(true);
    }

    private void ProcessUpgrade(UpgradeEffectSO e, ref string s)
    {
        if (e is UnlockItemUpgradeEffect uie)
        {
            foreach (var w in uie.weapons) CreateUnlockSlot(w);
            foreach (var r in uie.relics) CreateUnlockSlot(r);
        }
        else if (e.rewardIcon != null) CreateEffectSlot(e.rewardIcon);
        if (!string.IsNullOrEmpty(e.rewardText)) s += $"- {e.rewardText}\n";
    }

    private void ProcessAffection(AffectionEffect e, ref string s)
    {
        if (e is UnlockItemAffectionEffect aie)
        {
            foreach (var w in aie.weapons) CreateUnlockSlot(w);
            foreach (var r in aie.relics) CreateUnlockSlot(r);
        }
        else if (e.rewardIcon != null) CreateEffectSlot(e.rewardIcon);
        if (!string.IsNullOrEmpty(e.rewardText)) s += $"- {e.rewardText}\n";
    }

    private void CreateUnlockSlot(ScriptableObject d) => Instantiate(unlockSlotPrefab, slotParent).GetComponent<UnlockSlotUI>().Setup(d);
    private void CreateEffectSlot(Sprite i) => Instantiate(effectSlotPrefab, slotParent).GetComponent<RewardEffectSlotUI>().Setup(i);

    public void Close()
    {
        panelRoot.SetActive(false);

        // [핵심] DialogueManager 직접 호출 삭제. 진동벨(콜백)만 누릅니다.
        onCloseCallback?.Invoke();
        onCloseCallback = null; // 실행 후 초기화
    }
}