using UnityEngine;
using System;

public class UpgradeFeature : MonoBehaviour, INPCFeature
{
    // 1. 이 부품의 이름은 "Upgrade" 라고 명시
    public string FeatureName => "Upgrade";

    // 2. 기능 실행
    public void Execute(Action onComplete)
    {
        if (UpgradeManager.Instance != null)
        {
            UpgradeManager.Instance.ToggleUI();

            // UI가 닫혔을 때 실행할 일회용 리스너 (구독 해제까지 깔끔하게)
            Action handler = null;
            handler = () =>
            {
                UpgradeManager.Instance.OnUIClosed -= handler;

                // "나 볼일 다 끝났어!" 라고 보고 (대화 재개를 위해)
                onComplete?.Invoke();
            };

            UpgradeManager.Instance.OnUIClosed += handler;
        }
        else
        {
            Debug.LogWarning("[UpgradeFeature] UpgradeManager가 없습니다.");
            onComplete?.Invoke(); // 에러 방지를 위해 강제 완료 보고
        }
    }
}