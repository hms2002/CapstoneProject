using UnityEngine;
using System.Collections.Generic;
using System; // Action 사용을 위해 추가

public class UpgradeManager : MonoBehaviour
{
    public static UpgradeManager Instance { get; private set; }

    [SerializeField] private GameObject upgradeTreePanel;
    [SerializeField] private UpgradeDatabase upgradeDatabase;

    private Dictionary<int, UpgradeNodeSO> upgradeMap = new Dictionary<int, UpgradeNodeSO>();

    // 데이터 변경 시 UI 등을 갱신하라고 알리는 이벤트
    public Action OnDataChanged;

    // [핵심 SOLID 개선] UI가 닫혔음을 외부(대화 시스템 등)에 알리는 진동벨(이벤트)!
    // 이제 낡은 DialogueManager를 직접 부르지 않습니다.
    public Action OnUIClosed;

    private void Awake()
    {
        if (Instance == null)
        {
            Instance = this;
            DontDestroyOnLoad(gameObject);
        }
        else
        {
            Destroy(gameObject);
        }
        InitDB();
    }

    private void Start()
    {
        CheckAndUnlockNodes();
        ReapplyAllEffects();
    }

    private void InitDB()
    {
        if (upgradeDatabase == null) return;
        foreach (var node in upgradeDatabase.allUpgrades)
        {
            if (!upgradeMap.ContainsKey(node.nodeID)) upgradeMap.Add(node.nodeID, node);
        }
    }

    public void CheckAndUnlockNodes()
    {
        if (upgradeDatabase == null || GameDataManager.Instance == null) return;

        var data = GameDataManager.Instance.Data.upgradeData;
        bool isChanged = false;

        foreach (var node in upgradeDatabase.allUpgrades)
        {
            if (node == null) continue;

            if (data.purchasedIDs.Contains(node.nodeID) || data.unlockedIDs.Contains(node.nodeID)) continue;

            if (node.requiredParentIDs == null || node.requiredParentIDs.Count == 0)
            {
                data.unlockedIDs.Add(node.nodeID);
                isChanged = true;
                continue;
            }

            if (CheckParentsPurchased(node))
            {
                data.unlockedIDs.Add(node.nodeID);
                isChanged = true;
            }
        }

        if (isChanged)
        {
            GameDataManager.Instance.SaveData();
            OnDataChanged?.Invoke();
        }
    }

    private bool CheckParentsPurchased(UpgradeNodeSO node)
    {
        if (node.requiredParentIDs == null || node.requiredParentIDs.Count == 0) return true;

        var purchasedList = GameDataManager.Instance.Data.upgradeData.purchasedIDs;

        foreach (int parentID in node.requiredParentIDs)
        {
            if (!purchasedList.Contains(parentID)) return false;
        }
        return true;
    }

    public void TryBuyUpgrade(int id)
    {
        if (GetNodeStatus(id) != LockType.UnLocked) return;

        var node = GetUpgradeByID(id);
        if (node == null || GameDataManager.Instance.Data.magicStone < node.price) return;

        GameDataManager.Instance.Data.magicStone -= node.price;
        var data = GameDataManager.Instance.Data.upgradeData;

        data.unlockedIDs.Remove(id);
        data.purchasedIDs.Add(id);

        node.ApplyEffect(SampleTopDownPlayer.Instance);

        if (RewardDisplayUI.Instance != null)
            RewardDisplayUI.Instance.ShowReward(node.effects, null);

        CheckAndUnlockNodes();

        GameDataManager.Instance.SaveData();
        OnDataChanged?.Invoke();
    }

    private void ReapplyAllEffects()
    {
        if (SampleTopDownPlayer.Instance == null) return;
        foreach (var id in GameDataManager.Instance.Data.upgradeData.purchasedIDs)
        {
            GetUpgradeByID(id)?.ApplyEffect(SampleTopDownPlayer.Instance);
        }
    }

    public void ToggleUI()
    {
        bool nextState = !upgradeTreePanel.activeSelf;
        upgradeTreePanel.SetActive(nextState);

        if (nextState)
        {
            UIManager.Instance.RegisterUI("UpgradeTree");
        }
        else
        {
            CloseUI();
        }
    }

    public void CloseUI()
    {
        upgradeTreePanel.SetActive(false);
        UIManager.Instance.UnregisterUI("UpgradeTree");

        // [SOLID 완벽 해결] 더 이상 대화 매니저를 찾지 않습니다.
        // 그저 "나 닫혔어!" 하고 허공에 소리칠 뿐입니다.
        OnUIClosed?.Invoke();
    }

    public LockType GetNodeStatus(int id)
    {
        var data = GameDataManager.Instance.Data.upgradeData;
        if (data.purchasedIDs.Contains(id)) return LockType.Purchased;
        if (data.unlockedIDs.Contains(id)) return LockType.UnLocked;
        return LockType.Locked;
    }

    public UpgradeNodeSO GetUpgradeByID(int id)
    {
        upgradeMap.TryGetValue(id, out var node);
        return node;
    }

    public List<UpgradeNodeSO> GetAllUpgrades() => upgradeDatabase.allUpgrades;
}