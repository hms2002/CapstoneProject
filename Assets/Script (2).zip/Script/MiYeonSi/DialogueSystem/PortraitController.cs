using UnityEngine;
using UnityEngine.UI;
using UnityEngine.U2D.Animation;
using DG.Tweening;
using System.Collections.Generic;

public class PortraitController : MonoBehaviour
{
    [Header("데이터 연동")]
    public NPCData npcData;

    [Header("설정")]
    [Tooltip("표정 스프라이트 카테고리 이름 (예: Face)")]
    public string targetCategory = "Face";

    [Header("위치 설정 (화면 픽셀 좌표)")]
    [SerializeField] private float centerPosX = 0f;
    [SerializeField] private float sideOffset = 400f;
    [SerializeField] private float farSideOffset = 700f;
    [SerializeField] private float hidePosY = -200f;

    [Header("이모티콘 설정")]
    [Tooltip("EmoteController가 붙어있는 말풍선 프리팹")]
    public GameObject emotePrefab;

    [Header("초상화 동적 풀링 (스킵 광클 방어)")]
    [SerializeField] private Image portraitTemplate; // 기존 Image1을 템플릿으로 씁니다!
    [SerializeField] private SpriteLibrary spriteLibrary;

    private List<Image> portraitPool = new List<Image>();
    private Image currentPortrait; // 현재 화면에 가장 진하게 떠있는 메인 초상화

    private RectTransform rectTransform;
    private Vector2 defaultPos;
    private Vector3 defaultScale;

    private List<GameObject> emotePool = new List<GameObject>();

    private void Awake()
    {
        rectTransform = GetComponent<RectTransform>();
        if (spriteLibrary == null) spriteLibrary = GetComponent<SpriteLibrary>();

        if (rectTransform != null) defaultPos = rectTransform.anchoredPosition;
        defaultScale = transform.localScale;

        // 원본 템플릿을 풀에 넣고 꺼둡니다.
        if (portraitTemplate != null)
        {
            portraitTemplate.gameObject.SetActive(false);
            portraitPool.Add(portraitTemplate);
        }
    }

    private void Start()
    {
        if (npcData != null) ApplyNPCData(npcData);
    }

    public void ApplyNPCData(NPCData data)
    {
        this.npcData = data;

        if (data.spriteLibraryAsset != null)
        {
            if (spriteLibrary != null)
            {
                spriteLibrary.spriteLibraryAsset = data.spriteLibraryAsset;
                spriteLibrary.RefreshSpriteResolvers();
            }
            SetExpression("Normal");
        }
    }

    // =================================================================
    // [핵심] 사용 가능한 초상화 이미지를 풀에서 꺼내거나 새로 만듭니다.
    // 광클해서 3, 4개가 필요해지면 알아서 복사본을 생성합니다!
    // =================================================================
    private Image GetFreePortraitImage()
    {
        foreach (var img in portraitPool)
        {
            if (!img.gameObject.activeSelf) return img;
        }

        // 남는 게 없으면 새로 복사해서 풀에 추가
        Image newImg = Instantiate(portraitTemplate, portraitTemplate.transform.parent);
        portraitPool.Add(newImg);
        return newImg;
    }

    public void SetExpression(string label)
    {
        if (spriteLibrary == null || spriteLibrary.spriteLibraryAsset == null) return;

        Sprite newSprite = spriteLibrary.GetSprite(targetCategory, label);
        if (newSprite != null)
        {
            if (currentPortrait == null) currentPortrait = GetFreePortraitImage();

            currentPortrait.sprite = newSprite;
            currentPortrait.color = Color.white;
            currentPortrait.gameObject.SetActive(true);
            currentPortrait.transform.SetAsLastSibling();
        }
    }

    public void SetupSilhouetteMode(NPCData data)
    {
        ApplyNPCData(data);

        if (currentPortrait == null) currentPortrait = GetFreePortraitImage();

        currentPortrait.color = new Color(0, 0, 0, 0);
        currentPortrait.gameObject.SetActive(true);
        currentPortrait.transform.SetAsLastSibling();
    }

    public Tween GetSilhouetteFadeInTween(float duration)
    {
        if (currentPortrait == null) return null;
        return currentPortrait.DOFade(1f, duration);
    }

    public Tween GetColorizeTween(float duration)
    {
        if (currentPortrait == null) return null;
        return currentPortrait.DOColor(Color.white, duration);
    }

    // =================================================================
    // 무한 크로스 페이드 연출 (스킵 연타 시 안전장치 포함)
    // =================================================================
    public void DoCrossFade(string newEmotionLabel, float appearTime, float fadeOutTime)
    {
        if (spriteLibrary == null) return;

        Sprite newSprite = spriteLibrary.GetSprite(targetCategory, newEmotionLabel);
        if (newSprite == null) return;

        // 1. 새로운 빈 캔버스(Image)를 꺼내서 새 표정을 그립니다.
        Image nextImg = GetFreePortraitImage();
        nextImg.sprite = newSprite;
        nextImg.color = new Color(1, 1, 1, 0);
        nextImg.gameObject.SetActive(true);
        nextImg.transform.SetAsLastSibling(); // UI상 맨 앞으로 끌어올림

        Sequence seq = DOTween.Sequence();
        seq.Append(nextImg.DOFade(1f, appearTime));

        // 2. 현재 켜져 있는 '모든' 이전 초상화들을 찾아서 동시에 페이드 아웃 시킵니다!
        foreach (var img in portraitPool)
        {
            if (img != nextImg && img.gameObject.activeSelf)
            {
                Image fadingImg = img; // 클로저(Closure) 변수 캡처
                fadingImg.DOKill(); // 기존에 돌고 있던 트윈 애니메이션 강제 중지! (꼬임 방지)

                seq.Join(fadingImg.DOFade(0f, fadeOutTime).OnComplete(() =>
                {
                    fadingImg.gameObject.SetActive(false); // 다 사라지면 풀로 반납
                }));
            }
        }

        // 3. 메인 초상화를 방금 띄운 걸로 교체
        currentPortrait = nextImg;
    }

    public void ShowEmote(string emoteName)
    {
        if (emotePrefab == null || npcData == null) return;

        GameObject targetEmote = null;

        foreach (var emote in emotePool)
        {
            if (emote != null && !emote.activeSelf)
            {
                targetEmote = emote;
                break;
            }
        }

        if (targetEmote == null)
        {
            targetEmote = Instantiate(emotePrefab, transform);
            RectTransform rt = targetEmote.GetComponent<RectTransform>();
            if (rt != null)
            {
                rt.anchoredPosition = npcData.emoteOffset;
                rt.localScale = Vector3.one;
            }
            emotePool.Add(targetEmote);
        }

        EmoteController ctrl = targetEmote.GetComponent<EmoteController>();
        if (ctrl != null) ctrl.Init(emoteName);
    }

    public void PlayAction(string action)
    {
        if (rectTransform == null) return;

        rectTransform.DOKill();
        rectTransform.anchoredPosition = defaultPos;
        transform.localScale = defaultScale;
        transform.localRotation = Quaternion.identity;

        switch (action.ToLower())
        {
            case "jump": rectTransform.DOJumpAnchorPos(defaultPos, 50f, 1, 0.4f); break;
            case "shake": rectTransform.DOShakeAnchorPos(0.5f, 15f, 30, 90); break;
            case "zoom_in": transform.DOScale(defaultScale * 1.2f, 0.25f).SetEase(Ease.OutBack); break;
            case "nod": rectTransform.DOAnchorPosY(defaultPos.y - 15f, 0.15f).SetLoops(2, LoopType.Yoyo).SetEase(Ease.InOutSine); break;
        }
    }

    public void SetInitialPosition(string positionKey)
    {
        if (rectTransform == null) rectTransform = GetComponent<RectTransform>();

        rectTransform.anchorMin = new Vector2(0f, 0f);
        rectTransform.anchorMax = new Vector2(1f, 1f);
        rectTransform.pivot = new Vector2(0.5f, 0.5f);

        float targetX = GetTargetXByPositionKey(positionKey);

        rectTransform.anchoredPosition = new Vector2(targetX, hidePosY);
        defaultPos = new Vector2(targetX, 0f);
    }

    public void EnterAnimation()
    {
        if (rectTransform == null) rectTransform = GetComponent<RectTransform>();

        CanvasGroup cg = GetComponent<CanvasGroup>();
        if (cg == null) cg = gameObject.AddComponent<CanvasGroup>();

        cg.alpha = 0f;
        cg.DOFade(1f, 0.5f);

        if (rectTransform != null)
        {
            rectTransform.anchoredPosition = new Vector2(rectTransform.anchoredPosition.x, hidePosY);
            rectTransform.DOAnchorPosY(defaultPos.y, 0.5f).SetEase(Ease.OutBack);
        }
    }

    public void ExitAnimationAndDestroy()
    {
        foreach (var emote in emotePool) if (emote != null) Destroy(emote);
        emotePool.Clear();

        CanvasGroup cg = GetComponent<CanvasGroup>();
        if (cg != null) cg.DOFade(0f, 0.4f);

        if (rectTransform != null)
        {
            rectTransform.DOAnchorPosY(hidePosY, 0.4f)
                .OnComplete(() => Destroy(gameObject));
        }
        else Destroy(gameObject);
    }

    public void MovePosition(string positionKey)
    {
        if (rectTransform == null) return;
        float targetX = GetTargetXByPositionKey(positionKey);
        rectTransform.DOAnchorPosX(targetX, 0.5f).SetEase(Ease.OutQuart).OnComplete(() => defaultPos = rectTransform.anchoredPosition);
    }

    private float GetTargetXByPositionKey(string key)
    {
        switch (key.ToLower())
        {
            case "left": return -sideOffset;
            case "right": return sideOffset;
            case "center": return centerPosX;
            case "far_left": return -farSideOffset;
            case "far_right": return farSideOffset;
            default: return centerPosX;
        }
    }
}