using UnityEngine;
using UnityEngine.UI;
using TMPro;
using DG.Tweening;
using System;
using System.Collections.Generic;

public class DialogueView : MonoBehaviour
{
    [Header("UI 그룹 (CanvasGroup 필요)")]
    [SerializeField] private CanvasGroup mainPanelGroup;
    [SerializeField] private CanvasGroup affectionGroup;

    [Header("텍스트 컴포넌트")]
    [SerializeField] private TextMeshProUGUI nameText;
    [SerializeField] private TextMeshProUGUI dialogueText;

    [Header("연출 아이콘")]
    [SerializeField] private GameObject continueIcon; // 다음 대사 대기 아이콘 (역삼각형 등)

    [Header("선택지 UI (프리팹 방식)")]
    [SerializeField] private Transform choiceContainer; // 버튼들이 나열될 부모 (Vertical Layout Group 권장)
    [SerializeField] private GameObject choiceButtonPrefab; // 버튼 프리팹 (안에 TextMeshProUGUI 필수)

    private Tween typingTween;
    private List<GameObject> activeChoiceButtons = new List<GameObject>(); // 생성된 버튼 관리 리스트

    private void Awake()
    {
        if (mainPanelGroup != null)
        {
            mainPanelGroup.alpha = 0f;
            mainPanelGroup.gameObject.SetActive(false);
        }

        if (affectionGroup != null)
        {
            affectionGroup.alpha = 0f;
            affectionGroup.gameObject.SetActive(false);
        }

        // Continue Icon 초기화 및 무한 둥둥(Bounce) 애니메이션 세팅
        if (continueIcon != null)
        {
            continueIcon.SetActive(false); // 시작할 땐 무조건 꺼둠

            RectTransform iconRect = continueIcon.GetComponent<RectTransform>();
            if (iconRect != null)
            {
                // Y축으로 -10만큼 0.5초 동안 이동했다가 제자리로 돌아오는 무한 반복 애니메이션
                iconRect.DOAnchorPosY(iconRect.anchoredPosition.y - 10f, 0.5f)
                    .SetLoops(-1, LoopType.Yoyo)
                    .SetEase(Ease.InOutSine);
            }
        }

        ClearChoices(); // 시작 시 혹시 모를 버튼 찌꺼기 청소
    }

    public void ShowUI(bool isBoss, Action onComplete = null)
    {
        if (mainPanelGroup != null)
        {
            mainPanelGroup.gameObject.SetActive(true);

            Sequence seq = DOTween.Sequence();
            seq.Append(mainPanelGroup.DOFade(1f, 0.25f));

            if (isBoss && affectionGroup != null)
            {
                affectionGroup.gameObject.SetActive(true);
                seq.Join(affectionGroup.DOFade(1f, 0.25f));
            }

            seq.OnComplete(() => onComplete?.Invoke());
        }
        else onComplete?.Invoke();
    }

    public void TypeText(string speakerName, string text, Action onComplete = null)
    {
        if (nameText != null) nameText.text = speakerName;
        if (dialogueText != null) dialogueText.text = "";

        // 글자가 타이핑되기 시작하면 아이콘 숨기기
        if (continueIcon != null) continueIcon.SetActive(false);

        if (typingTween != null) typingTween.Kill();

        if (dialogueText != null)
        {
            typingTween = dialogueText.DOText(text, text.Length * 0.05f)
                .SetEase(Ease.Linear)
                .OnComplete(() =>
                {
                    // 정상적으로 타이핑이 다 끝나면 아이콘 뿅! 나타나게 하기
                    if (continueIcon != null) continueIcon.SetActive(true);
                    onComplete?.Invoke();
                });
        }
    }

    public void SkipTyping(string fullText)
    {
        if (typingTween != null) typingTween.Kill();
        if (dialogueText != null) dialogueText.text = fullText;

        // 스킵해서 글자가 다 찍히면 즉시 아이콘 켜기
        if (continueIcon != null) continueIcon.SetActive(true);
    }

    // =================================================================
    // 선택지 동적 생성 (프리팹 방식 복구)
    // =================================================================
    public void ShowChoices(List<Ink.Runtime.Choice> choices, Action<int> onChoiceSelected)
    {
        ClearChoices(); // 기존 버튼 밀어버리기

        // 선택지가 떴을 때는 스킵이 아니라 '클릭'을 해야 하므로 Continue 아이콘 숨기기
        if (continueIcon != null) continueIcon.SetActive(false);

        if (choiceContainer == null || choiceButtonPrefab == null)
        {
            Debug.LogError("[DialogueView] 선택지 컨테이너나 프리팹이 연결되지 않았습니다!");
            return;
        }

        foreach (var choice in choices)
        {
            GameObject btnObj = Instantiate(choiceButtonPrefab, choiceContainer);
            activeChoiceButtons.Add(btnObj);

            // 버튼 안의 텍스트 변경
            TextMeshProUGUI btnText = btnObj.GetComponentInChildren<TextMeshProUGUI>();
            if (btnText != null) btnText.text = choice.text;

            // 클릭 이벤트 연결 (클릭 시 콜백으로 인덱스 번호 전달)
            Button btn = btnObj.GetComponent<Button>();
            if (btn != null)
            {
                int index = choice.index;
                btn.onClick.AddListener(() =>
                {
                    ClearChoices(); // 누르는 즉시 모든 버튼 삭제
                    onChoiceSelected?.Invoke(index); // 컨트롤러에게 몇 번 눌렀는지 보고
                });
            }
        }
    }

    public void ClearChoices()
    {
        foreach (var btn in activeChoiceButtons)
        {
            if (btn != null) Destroy(btn);
        }
        activeChoiceButtons.Clear();
    }

    public void HideUI(Action onComplete = null)
    {
        ClearChoices(); // 퇴장 시 버튼도 깔끔하게 청소

        // 대화창이 닫힐 때 아이콘도 확실하게 꺼줌
        if (continueIcon != null) continueIcon.SetActive(false);

        Sequence seq = DOTween.Sequence();

        if (mainPanelGroup != null) seq.Append(mainPanelGroup.DOFade(0f, 0.25f));
        if (affectionGroup != null && affectionGroup.gameObject.activeSelf) seq.Join(affectionGroup.DOFade(0f, 0.25f));

        seq.OnComplete(() =>
        {
            if (mainPanelGroup != null) mainPanelGroup.gameObject.SetActive(false);
            if (affectionGroup != null) affectionGroup.gameObject.SetActive(false);
            onComplete?.Invoke();
        });
    }
}