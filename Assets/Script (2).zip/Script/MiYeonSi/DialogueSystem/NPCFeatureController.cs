using UnityEngine;
using System;
using System.Collections.Generic;

public class NPCFeatureController : MonoBehaviour
{
    // 내 몸(NPC)에 붙어있는 기능(Feature)들을 이름표(string)와 함께 보관할 딕셔너리
    private Dictionary<string, INPCFeature> featureMap = new Dictionary<string, INPCFeature>(StringComparer.OrdinalIgnoreCase);

    private void Awake()
    {
        // 1. 내 게임 오브젝트에 붙어있는 모든 INPCFeature 부품들을 싹 긁어모음
        INPCFeature[] attachedFeatures = GetComponents<INPCFeature>();

        // 2. 딕셔너리에 이름표를 달아서 예쁘게 정리 ("Upgrade" -> UpgradeFeature)
        foreach (var feature in attachedFeatures)
        {
            featureMap[feature.FeatureName] = feature;
        }
    }

    // TagHandler에서 #feature:Upgrade 같은 태그를 읽으면 이 함수가 호출됨
    public void ExecuteFeature(string requestedFeature)
    {
        // 딕셔너리에서 요청받은 이름의 부품을 꺼내본다
        if (featureMap.TryGetValue(requestedFeature, out INPCFeature feature))
        {
            // 부품이 있으면 실행! (그리고 끝나면 대화를 재개하라는 콜백을 넘겨줌)
            feature.Execute(() =>
            {
                if (DialogueController.Instance != null)
                {
                    DialogueController.Instance.ResumeDialogue();
                }
            });
        }
        else
        {
            // 그런 부품이 내 몸에 없다면 무시하고 바로 대화 재개
            Debug.LogWarning($"[NPCFeatureController] 이 NPC에는 '{requestedFeature}' 기능이 안 붙어있습니다!");

            if (DialogueController.Instance != null)
            {
                DialogueController.Instance.ResumeDialogue();
            }
        }
    }
}