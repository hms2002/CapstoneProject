using UnityEngine;
using System.Collections;
using Unity.Cinemachine;
using DG.Tweening;

public class BossTalkManager : MonoBehaviour
{
    [Header("데이터 설정")]
    [SerializeField] private TextAsset inkJSON;
    [SerializeField] private NPCData npcData;

    [Header("카메라 설정")]
    [SerializeField] private CinemachineCamera playerCam;
    [SerializeField] private CinemachineCamera bossCam;

    // [삭제됨] 구시대 매니저의 Direction 열거형은 삭제되었습니다. 
    // 새로운 MVC 시스템에서는 위치와 연출을 Director와 Ink 태그(#pos:Left 등)가 전담합니다.

    private CinemachineBrain brain;

    void Awake()
    {
        if (Camera.main != null)
            brain = Camera.main.GetComponent<CinemachineBrain>();
    }

    void Start()
    {
        if (bossCam == null || playerCam == null || brain == null) return;
        StartCoroutine(EncounterSequence());
    }

    IEnumerator EncounterSequence()
    {
        // 1. 플레이어 정지
        if (TempPlayer.Instance != null)
            TempPlayer.Instance.SetInteractState(InteractState.Talking);

        // 2. 카메라 이동
        bossCam.Priority = 20;
        yield return new WaitForSeconds(0.1f);
        yield return new WaitUntil(() => !brain.IsBlending);

        // 3. 카메라 도착 후 UI 연출 및 대화 시작
        // [핵심 수정] 새로운 두뇌(DialogueController)에게 대화 시작을 요청합니다.
        if (DialogueController.Instance != null)
        {
            // 컨트롤러가 알아서 Director에게 실루엣 연출을 지시하고, View에게 대화창을 띄우게 합니다.
            DialogueController.Instance.EnterDialogueMode(inkJSON, npcData);
        }
        else
        {
            Debug.LogError("[BossTalkManager] DialogueController 인스턴스를 찾을 수 없습니다!");
        }

        // 4. 대화 종료 대기
        // [핵심 수정] 새로운 컨트롤러의 isPlaying 상태를 체크합니다.
        yield return new WaitUntil(() => DialogueController.Instance == null || !DialogueController.Instance.isPlaying);

        // 5. 카메라 복구
        bossCam.Priority = 5;
        yield return new WaitForSeconds(0.1f);
        yield return new WaitUntil(() => !brain.IsBlending);

        if (TempPlayer.Instance != null)
            TempPlayer.Instance.SetInteractState(InteractState.Idle);

        // 대화가 끝나면 보스 드랍 실행 (기존 로직 유지)
        var bossDrop = GetComponent<BossDrop>();
        if (bossDrop != null)
        {
            bossDrop.OnBossDead();
        }
    }
}