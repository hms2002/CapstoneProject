using UnityEngine;
using UnityEngine.UI;
using DG.Tweening;
using System;

public class CinematicDirector : MonoBehaviour
{
    [Header("배경 연출")]
    [SerializeField] private Image dimPanel; // 화면 뒤에 깔릴 반투명 검은 판넬
    [SerializeField] private Transform effectParent; // 보스 배경 이펙트가 생성될 위치

    [Header("연결된 컨트롤러")]
    [SerializeField] private PortraitController portraitController;

    private GameObject currentBossEffect;

    private void Awake()
    {
        if (dimPanel != null)
        {
            dimPanel.color = new Color(0, 0, 0, 0);
            dimPanel.gameObject.SetActive(false);
        }
    }

    // 대화 시작 연출 (보스 vs 일반 분기 처리)
    public void PlayIntro(NPCData npcData, Action onComplete)
    {
        if (npcData.isBoss)
        {
            PlayBossIntroSequence(npcData, onComplete);
        }
        else
        {
            // 일반 NPC는 배경/실루엣 연출 없이 그냥 초상화만 띄움
            if (portraitController != null)
            {
                portraitController.SetInitialPosition("Center");
                portraitController.EnterAnimation();
            }
            onComplete?.Invoke();
        }
    }

    // 보스 전용 인트로 시퀀스 (Dim -> 이펙트 -> 실루엣 -> 원색)
    private void PlayBossIntroSequence(NPCData npcData, Action onComplete)
    {
        Sequence seq = DOTween.Sequence();

        // 1. [0.25초] 검은 장막(Dim) 서서히 생성
        if (dimPanel != null)
        {
            dimPanel.gameObject.SetActive(true);
            seq.Append(dimPanel.DOFade(0.7f, 0.25f));
        }

        // 2. [0.5초] 보스 배경 이펙트 출력 (프리팹 존재 여부에 따라 처리)
        // 만약 NPCData에 bossEffectPrefab 변수가 없다면 이 부분을 주석 처리하세요.
        /*
        if (npcData.bossEffectPrefab != null)
        {
            seq.JoinCallback(() => 
            {
                currentBossEffect = Instantiate(npcData.bossEffectPrefab, effectParent);
            });
            seq.AppendInterval(0.5f); // 이펙트 등장 대기
        }
        */

        // 3. [0.25초] 보스 실루엣(RGB:0, Alpha: 0->1) 등장
        if (portraitController != null)
        {
            seq.AppendCallback(() => portraitController.SetupSilhouetteMode(npcData));
            seq.Append(portraitController.GetSilhouetteFadeInTween(0.25f));

            // 4. [0.25초] 보스 이미지 교체 (RGB: 0->255 원색 복귀)
            seq.Append(portraitController.GetColorizeTween(0.25f));
        }

        // 모든 시퀀스가 끝나면 끝났다고 보고
        seq.OnComplete(() => onComplete?.Invoke());
    }

    // 표정 크로스 페이드 연출 지시
    public void ChangePortrait(string emotion)
    {
        if (portraitController != null)
        {
            // 새 이미지는 0.01초 등장, 옛날 이미지는 0.25초 삭제
            portraitController.DoCrossFade(emotion, 0.01f, 0.25f);
        }
    }

    // 대화 종료 시 퇴장 연출
    public void PlayOutro(Action onComplete)
    {
        Sequence seq = DOTween.Sequence();

        if (dimPanel != null && dimPanel.gameObject.activeSelf)
        {
            seq.Append(dimPanel.DOFade(0f, 0.25f));
        }

        if (currentBossEffect != null)
        {
            Destroy(currentBossEffect);
        }

        if (portraitController != null)
        {
            portraitController.ExitAnimationAndDestroy();
        }

        seq.OnComplete(() =>
        {
            if (dimPanel != null) dimPanel.gameObject.SetActive(false);
            onComplete?.Invoke();
        });
    }
}