using System;
using System.Collections.Generic;
using UnityEngine;

public class AffectionManager : MonoBehaviour
{
    public static AffectionManager Instance { get; private set; }

    private Dictionary<int, int> npcAffectionDic = new Dictionary<int, int>();

    private int currentNpcId;
    private AffectionUI linkedUI;

    public event Action<int, int> OnAffectionChanged;

    private void Awake()
    {
        if (Instance == null) { Instance = this; DontDestroyOnLoad(gameObject); }
        else Destroy(gameObject);
    }

    private void Start()
    {
        LoadAffectionData();
    }

    private void LoadAffectionData()
    {
        if (GameDataManager.Instance == null) return;

        var savedList = GameDataManager.Instance.Data.affectionData.affectionRecords;

        foreach (var record in savedList)
        {
            if (npcAffectionDic.ContainsKey(record.npcId))
                npcAffectionDic[record.npcId] = record.amount;
            else
                npcAffectionDic.Add(record.npcId, record.amount);
        }

        Debug.Log($"[AffectionManager] 데이터 로드 완료. 기록된 NPC 수: {savedList.Count}");
    }

    public void SetLinkedUI(AffectionUI ui) => linkedUI = ui;

    public void SetCurrentNPC(int npcId)
    {
        currentNpcId = npcId;
        if (linkedUI != null) linkedUI.Setup(GetAffection(npcId));
    }

    public int GetAffection() => GetAffection(currentNpcId);

    public int GetAffection(int npcId)
    {
        if (npcAffectionDic.ContainsKey(npcId)) return npcAffectionDic[npcId];
        return 0;
    }

    // [수정] 콜백(onComplete) 추가 및 DialogueManager 종속성 제거
    public bool AddAffection(NPCData data, int amount, System.Action onComplete = null)
    {
        if (data == null)
        {
            Debug.LogError("[AffectionManager] NPC 데이터가 Null입니다!");
            onComplete?.Invoke();
            return false;
        }

        int id = data.id;
        int oldAffection = GetAffection(id);

        if (!npcAffectionDic.ContainsKey(id)) npcAffectionDic[id] = 0;
        npcAffectionDic[id] += amount;
        int newAffection = npcAffectionDic[id];

        // 게임 데이터 갱신 (하지만 파일 쓰기인 SaveData()는 호출하지 않음 = 지연 저장)
        UpdateGameDataMemoryOnly(id, newAffection);

        Debug.Log($"<color=cyan>[AffectionManager] {data.npcName}(ID:{id}) 호감도 변경: {oldAffection} -> {newAffection} (증가량: {amount})</color>");

        bool hasReward = false;
        foreach (var reward in data.affectionRewards)
        {
            if (reward.targetLevel > oldAffection && reward.targetLevel <= newAffection)
            {
                hasReward = true;
                Debug.Log($"<color=green>[AffectionManager] 보상 달성! 목표 레벨: {reward.targetLevel}</color>");
                break;
            }
        }

        if (linkedUI != null && linkedUI.gameObject.activeInHierarchy)
        {
            Debug.Log("[AffectionManager] UI 연출 시작");
            linkedUI.PlayGainAnimation(oldAffection, newAffection, () =>
            {
                Debug.Log("[AffectionManager] UI 연출 종료 -> 다음 단계 진행");
                if (hasReward) CheckRewards(data, oldAffection, newAffection, onComplete);
                else onComplete?.Invoke();
            });
        }
        else
        {
            Debug.LogWarning("[AffectionManager] 연결된 AffectionUI가 없거나 비활성화 상태입니다. 연출 없이 값만 변경합니다.");
            if (hasReward) CheckRewards(data, oldAffection, newAffection, onComplete);
            else onComplete?.Invoke();
        }

        OnAffectionChanged?.Invoke(id, newAffection);
        return true;
    }

    // [수정] 메모리 상태만 갱신하고 디스크 저장(SaveData)은 뺌
    private void UpdateGameDataMemoryOnly(int npcId, int amount)
    {
        if (GameDataManager.Instance == null) return;

        var recordList = GameDataManager.Instance.Data.affectionData.affectionRecords;
        var record = recordList.Find(x => x.npcId == npcId);

        if (record != null)
        {
            record.amount = amount;
        }
        else
        {
            recordList.Add(new AffectionRecord(npcId, amount));
        }
    }

    // [수정] 매니저 대신 콜백 릴레이
    private void CheckRewards(NPCData data, int fromLevel, int toLevel, System.Action onComplete)
    {
        List<AffectionEffect> earnedEffects = new List<AffectionEffect>();

        foreach (var reward in data.affectionRewards)
        {
            if (reward.targetLevel > fromLevel && reward.targetLevel <= toLevel)
            {
                if (reward.effect != null)
                {
                    reward.effect.Execute();
                    earnedEffects.Add(reward.effect);
                }
            }
        }

        if (earnedEffects.Count > 0 && RewardDisplayUI.Instance != null)
        {
            RewardDisplayUI.Instance.ShowReward(null, earnedEffects, onComplete);
        }
        else
        {
            onComplete?.Invoke();
        }
    }

    public void SetAffection(int npcId, int value)
    {
        npcAffectionDic[npcId] = value;
        UpdateGameDataMemoryOnly(npcId, value);
    }
}