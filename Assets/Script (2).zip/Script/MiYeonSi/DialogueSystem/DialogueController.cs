using UnityEngine;
using System.Collections.Generic;
using Ink.Runtime;
using System;

public class DialogueController : MonoBehaviour
{
    public static DialogueController Instance { get; private set; }

    [Header("연결된 시스템 (MVC)")]
    [SerializeField] private DialogueView view;
    [SerializeField] private CinematicDirector director;
    [SerializeField] private PortraitController portraitController;

    [Header("태그 핸들러 (번역가)")]
    [SerializeField] private DialogueTagHandler tagHandler;

    [Header("입력 설정")]
    [SerializeField] private KeyCode skipKey = KeyCode.Space;
    [SerializeField] private KeyCode skipKeyAlt = KeyCode.F;

    private Story currentStory;
    public bool isPlaying { get; private set; } = false;
    private bool isTyping = false;
    private bool isChoosing = false;

    private string currentSpeaker = "";
    private string currentText = "";
    private NPCData currentNPCData;

    private NPCFeatureController currentFeatureController;

    private void Awake()
    {
        if (Instance != null && Instance != this) Destroy(gameObject);
        else Instance = this;

        if (tagHandler != null)
        {
            tagHandler.OnPortraitFaceRequested += (val) => director.ChangePortrait(val);
            tagHandler.OnPortraitEmoteRequested += (val) => { if (portraitController != null) portraitController.ShowEmote(val); };
            tagHandler.OnPortraitActionRequested += (val) => { if (portraitController != null) portraitController.PlayAction(val); };
            tagHandler.OnPortraitMoveRequested += (val) => { if (portraitController != null) portraitController.MovePosition(val); };

            tagHandler.OnFeatureRequested += (val) =>
            {
                if (currentFeatureController != null) currentFeatureController.ExecuteFeature(val);
                else Debug.LogWarning($"[DialogueController] Feature({val})가 호출되었으나 연결된 NPCFeatureController가 없습니다!");
            };
        }
    }

    private void Update()
    {
        if (!isPlaying || isChoosing) return;

        if (Input.GetMouseButtonDown(0) || Input.GetKeyDown(skipKey) || Input.GetKeyDown(skipKeyAlt))
        {
            if (isTyping)
            {
                view.SkipTyping(currentText);
                isTyping = false;
                DisplayChoicesIfNeeded();
            }
            else
            {
                ContinueStory();
            }
        }
    }

    public void EnterDialogueMode(TextAsset inkJSON, NPCData npcData, NPCFeatureController featureController = null)
    {
        if (isPlaying) return;

        isPlaying = true;
        isTyping = false;
        isChoosing = false;

        currentNPCData = npcData;
        currentFeatureController = featureController;

        currentStory = new Story(inkJSON.text);
        currentSpeaker = npcData.npcName;

        director.PlayIntro(npcData, () =>
        {
            view.ShowUI(npcData.isBoss, () =>
            {
                ContinueStory();
            });
        });
    }

    private void ContinueStory()
    {
        if (currentStory.canContinue)
        {
            currentText = currentStory.Continue();

            HandleSpeakerTag(currentStory.currentTags);

            bool isBlocking = false;
            if (tagHandler != null)
            {
                isBlocking = tagHandler.ProcessTags(currentStory.currentTags, currentNPCData);
            }

            if (!isBlocking)
            {
                isTyping = true;
                view.TypeText(currentSpeaker, currentText, () =>
                {
                    isTyping = false;
                    DisplayChoicesIfNeeded();
                });
            }
        }
        else if (currentStory.currentChoices.Count > 0)
        {
            DisplayChoicesIfNeeded();
        }
        else
        {
            ExitDialogueMode();
        }
    }

    private void HandleSpeakerTag(List<string> currentTags)
    {
        foreach (string tag in currentTags)
        {
            string[] splitTag = tag.Split(':');
            if (splitTag.Length != 2) continue;

            if (splitTag[0].Trim().ToLower() == "speaker")
            {
                currentSpeaker = splitTag[1].Trim();
                break;
            }
        }
    }

    private void DisplayChoicesIfNeeded()
    {
        if (currentStory.currentChoices.Count > 0)
        {
            isChoosing = true;
            view.ShowChoices(currentStory.currentChoices, (choiceIndex) =>
            {
                currentStory.ChooseChoiceIndex(choiceIndex);
                isChoosing = false;
                ContinueStory();
            });
        }
    }

    private void ExitDialogueMode()
    {
        isPlaying = false;
        view.HideUI(() =>
        {
            director.PlayOutro(() =>
            {
                currentStory = null;
                currentFeatureController = null;
            });
        });
    }

    // =================================================================
    // [NEW] 외부(상점, 업그레이드 등)에서 볼일이 끝난 후 대화를 재개시키는 함수
    // =================================================================
    public void ResumeDialogue()
    {
        // 대화 중이고, 현재 글자가 쳐지는 중이 아니며, 선택지 고르는 중이 아닐 때만 다음 대사로!
        if (isPlaying && !isTyping && !isChoosing)
        {
            ContinueStory();
        }
    }   

    private void OnDestroy()
    {
        if (tagHandler != null)
        {
            tagHandler.OnPortraitFaceRequested -= (val) => director.ChangePortrait(val);
            tagHandler.OnPortraitEmoteRequested -= (val) => { if (portraitController != null) portraitController.ShowEmote(val); };
            tagHandler.OnPortraitActionRequested -= (val) => { if (portraitController != null) portraitController.PlayAction(val); };
            tagHandler.OnPortraitMoveRequested -= (val) => { if (portraitController != null) portraitController.MovePosition(val); };
            tagHandler.OnFeatureRequested -= (val) => { if (currentFeatureController != null) currentFeatureController.ExecuteFeature(val); };
        }
    }
}