using UnityEngine;

public class DialogueTrigger : MonoBehaviour, IInteractable
{
    [Header("데이터 설정")]
    [SerializeField] private NPCData npcData;
    [SerializeField] private TextAsset inkJSON;

    [Header("시각적 가이드")]
    [SerializeField] private GameObject visualCue; // 기존 머리 위 F 아이콘

    [SerializeField] private SpriteRenderer spriteRenderer;
    private MaterialPropertyBlock propBlock;

    // 친구가 준 셰이더의 프로퍼티 이름에 맞춤
    private static readonly int OutlineEnabledID = Shader.PropertyToID("_OutlineEnabled");
    private static readonly int OutlineColorID = Shader.PropertyToID("_OutlineColor");

    // 이 NPC가 가진 기능 컨트롤러 (상점, 퀘스트 등)
    private NPCFeatureController featureController;

    private void Awake()
    {
        propBlock = new MaterialPropertyBlock();
        if (visualCue != null) visualCue.SetActive(false);

        featureController = GetComponent<NPCFeatureController>();

        // 초기 상태: 테두리 끄기
        OnUnHighlight();
    }

    public void OnPlayerNearby()
    {
        if (visualCue != null) visualCue.SetActive(true);
    }

    public void OnPlayerLeave()
    {
        if (visualCue != null) visualCue.SetActive(false);
    }

    public void OnHighlight()
    {
        if (spriteRenderer == null) return;

        spriteRenderer.GetPropertyBlock(propBlock);
        propBlock.SetFloat(OutlineEnabledID, 1f);
        spriteRenderer.SetPropertyBlock(propBlock);
    }

    public void OnUnHighlight()
    {
        if (spriteRenderer == null) return;

        spriteRenderer.GetPropertyBlock(propBlock);
        propBlock.SetFloat(OutlineEnabledID, 0f);
        spriteRenderer.SetPropertyBlock(propBlock);
    }

    public void OnPlayerInteract(IPlayerInteractor player)
    {
        if (CanInteract(player))
        {
            // [핵심 수정] 새로운 MVC 두뇌(DialogueController) 호출
            // 방향(Direction)은 빼고, featureController는 넘겨줍니다.
            if (DialogueController.Instance != null)
            {
                DialogueController.Instance.EnterDialogueMode(inkJSON, npcData, featureController);
            }
        }
    }

    public bool CanInteract(IPlayerInteractor player)
    {
        // [핵심 수정] 대화 중이 아닐 때만 상호작용 가능
        return DialogueController.Instance != null && !DialogueController.Instance.isPlaying;
    }

    public void GetInteract(string text) { }
    public InteractState GetInteractType() => InteractState.Talking;
    public string GetInteractDescription() => "대화하기";
}