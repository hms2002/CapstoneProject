using System;
using System.Collections.Generic;
using UnityEngine;

public class DialogueTagHandler : MonoBehaviour
{
    // [핵심] Controller에게 보고할 진동벨(이벤트)들
    public Action<string> OnFeatureRequested;
    public Action<string> OnPortraitFaceRequested;
    public Action<string> OnPortraitEmoteRequested;
    public Action<string> OnPortraitActionRequested;
    public Action<string> OnPortraitMoveRequested;

    // 태그를 분석하고 이벤트를 발생시킵니다.
    public bool ProcessTags(List<string> tags, NPCData currentNPC)
    {
        bool isBlocking = false;
        if (tags == null || tags.Count == 0) return false;

        foreach (string tag in tags)
        {
            string[] split = tag.Split(':');
            if (split.Length == 0) continue;

            string key = split[0].Trim().ToLower();
            string val = split.Length > 1 ? split[1].Trim() : "";

            switch (key)
            {
                case "feature":
                    OnFeatureRequested?.Invoke(val); // "Feature 실행해!" 라고 소리침
                    isBlocking = true;
                    break;

                case "add_aff":
                    if (AffectionManager.Instance != null && AffectionManager.Instance.AddAffection(currentNPC, int.Parse(val)))
                    {
                        isBlocking = true;
                    }
                    break;

                case "face":
                    OnPortraitFaceRequested?.Invoke(val); // "표정 바꿔!" 라고 소리침
                    break;

                case "emote":
                    OnPortraitEmoteRequested?.Invoke(val);
                    break;

                case "action":
                    OnPortraitActionRequested?.Invoke(val);
                    break;

                case "pos":
                case "move":
                    OnPortraitMoveRequested?.Invoke(val);
                    break;

                default:
                    // 복합 태그나 예외 처리 (필요시 확장)
                    Debug.Log($"[TagHandler] 처리되지 않은 태그: {tag}");
                    break;
            }
        }
        return isBlocking;
    }
}