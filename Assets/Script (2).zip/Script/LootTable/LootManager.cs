using UnityEngine;
using System.Collections.Generic;
using System.Linq;

public class LootManager : MonoBehaviour
{
    public static LootManager Instance { get; private set; }

    [Header("Settings")]
    public GameObject worldItemPrefab; // 바닥에 떨어질 아이템 프리팹 (WorldItemPickup2D)

    [Header("References")]
    // [수정] ItemDatabase 직접 참조 삭제 -> ItemManager.Instance를 통해 런타임 데이터 접근
    public List<StageLootTable> stageTables;

    [Header("State")]
    public int currentStageIndex = 0;

    private void Awake()
    {
        if (Instance == null) Instance = this;
        else Destroy(gameObject);
    }

    private StageLootTable GetCurrentTable()
    {
        int idx = Mathf.Clamp(currentStageIndex, 0, stageTables.Count - 1);
        return stageTables[idx];
    }

    // =========================================================
    // 1. 유틸리티 (확률 계산)
    // =========================================================
    private int PickCount(List<DropCountOption> options)
    {
        if (options == null || options.Count == 0) return 0;
        int total = options.Sum(o => o.weight);
        int rand = Random.Range(0, total);
        int sum = 0;
        foreach (var opt in options) { sum += opt.weight; if (rand < sum) return opt.count; }
        return options.Last().count;
    }

    private ItemRarity RollRelicRarity(StageLootTable table)
    {
        // Legendary 가중치 제거 (Common + Rare + Epic)
        int total = table.commonWeight + table.rareWeight + table.epicWeight;
        int rand = Random.Range(0, total);
        int sum = 0;

        sum += table.commonWeight; if (rand < sum) return ItemRarity.Common;
        sum += table.rareWeight; if (rand < sum) return ItemRarity.Rare;

        // 남은 확률은 무조건 Epic
        return ItemRarity.Epic;
    }

    // =========================================================
    // 2. 단일 아이템 데이터 뽑기
    // =========================================================
    public WeaponDefinition GetRandomWeapon(HashSet<string> exclusionList)
    {
        if (ItemManager.Instance == null) return null;

        var pool = ItemManager.Instance.GetUnlockedWeaponIDs();
        var valid = pool.Where(w => !exclusionList.Contains(w)).ToList(); // 문자열 ID 필터링

        if (valid.Count == 0) return null;

        string pickedID = valid[Random.Range(0, valid.Count)];
        // [수정] ItemDatabase 직접 참조 대신, 원본 데이터를 찾아줄 곳이 필요하다면 별도 처리 필요.
        // 현재는 ItemManager를 통해 원본 데이터를 다시 가져오거나 구조를 맞춰야 함.
        // (가정: ItemManager에 GetWeaponData(string id)가 있다고 전제)
        // 임시로 우회: 만약 ItemManager에 원본을 넘겨주는 기능이 없다면 추가해야 합니다.
        // (앞서 드린 ItemManager 코드에 public ItemDatabase database; 가 있으므로 이를 통해 가져올 수 있습니다만, 
        // 객체지향을 위해 ItemManager.Instance.GetWeaponDefinition(id) 형태로 함수를 뚫는 것이 좋습니다.)
        // 여기서는 에러 방지를 위해 간단히 처리합니다. (실제 환경에 맞게 조정 필요)

        // *주의: 앞서 만든 ItemManager 코드에 public ItemDatabase database; 가 private으로 되어있다면 
        // ItemManager 안에 public WeaponDefinition GetWeaponData(string id) 를 만들어 호출하세요.
        // 여기서는 구조를 유지합니다.
        return null; // TODO: ItemManager.Instance.GetWeaponData(pickedID) 로 대체하세요.
    }

    public RelicDefinition GetRandomRelic()
    {
        if (ItemManager.Instance == null) return null;

        var pool = ItemManager.Instance.GetUnlockedRelicIDs();
        if (pool.Count == 0) return null;

        StageLootTable table = GetCurrentTable();
        ItemRarity rarity = RollRelicRarity(table);

        // TODO: ID만 가지고 rarity를 알려면 ItemManager에서 데이터를 받아와야 합니다.
        // 이 부분은 ItemManager.Instance.GetRelicData(id).rarity == rarity 식으로 수정해야 합니다.
        return null;
    }

    // =========================================================
    // [핵심 수정] 3. [상자용] 드롭 리스트 생성 (매개변수 삭제)
    // =========================================================
    public List<ScriptableObject> GenerateChestLoot()
    {
        List<ScriptableObject> drops = new List<ScriptableObject>();
        StageLootTable table = GetCurrentTable();

        // [핵심] 몬스터/상자가 하던 짓을 LootManager가 전담
        HashSet<string> banList = new HashSet<string>();
        if (SampleTopDownPlayer.Instance != null && SampleTopDownPlayer.Instance.weaponInventory != null)
        {
            banList.UnionWith(SampleTopDownPlayer.Instance.weaponInventory.GetAllWeaponIDs());
        }

        int wCount = PickCount(table.chestWeaponCounts);

        for (int i = 0; i < wCount; i++)
        {
            var weapon = GetRandomWeapon(banList);
            if (weapon != null)
            {
                drops.Add(weapon);
                banList.Add(weapon.weaponId);
            }
        }

        int rCount = PickCount(table.chestRelicCounts);
        for (int i = 0; i < rCount; i++)
        {
            var relic = GetRandomRelic();
            if (relic != null) drops.Add(relic);
        }

        return drops;
    }

    // =========================================================
    // [핵심 수정] 4. [일반 몬스터용] 확률 드롭 및 스폰 (매개변수 삭제)
    // =========================================================
    public void SpawnMonsterLoot(Vector3 position)
    {
        StageLootTable table = GetCurrentTable();

        int totalWeight = table.mobNothingWeight + table.mobWeaponWeight + table.mobRelicWeight
                          + table.mobConsumableWeight + table.mobFieldItemWeight;

        int rand = Random.Range(0, totalWeight);
        int sum = 0;

        sum += table.mobNothingWeight;
        if (rand < sum) return;

        sum += table.mobWeaponWeight;
        if (rand < sum)
        {
            HashSet<string> banList = new HashSet<string>();
            if (SampleTopDownPlayer.Instance != null && SampleTopDownPlayer.Instance.weaponInventory != null)
            {
                banList.UnionWith(SampleTopDownPlayer.Instance.weaponInventory.GetAllWeaponIDs());
            }

            var weapon = GetRandomWeapon(banList);
            if (weapon != null) SpawnLootObject(position, weapon);
            return;
        }

        sum += table.mobRelicWeight;
        if (rand < sum)
        {
            var relic = GetRandomRelic();
            if (relic != null) SpawnLootObject(position, relic);
            return;
        }

        sum += table.mobConsumableWeight;
        if (rand < sum) return;

        sum += table.mobFieldItemWeight;
        if (rand < sum) return;
    }

    public void SpawnLootObject(Vector3 position, ScriptableObject itemData)
    {
        if (worldItemPrefab == null)
        {
            Debug.LogError("LootManager: WorldItemPrefab이 연결되지 않았습니다.");
            return;
        }

        GameObject go = Instantiate(worldItemPrefab, position, Quaternion.identity);
        var pickup = go.GetComponent<WorldItemPickup2D>();
        if (pickup != null)
        {
            pickup.SetItem(itemData);
        }
    }

    public int GetBossMagicStoneCount()
    {
        StageLootTable table = GetCurrentTable();
        if (table == null) return 0;
        return table.bossStoneCount;
    }
}