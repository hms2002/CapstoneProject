using System;
using System.Collections.Generic;
using System.Text;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityGAS;

/// <summary>
/// 책임 : 아이템 도감 오른쪽 페이지에 무기/유물/소모품 상세 정보를 표시한다.
/// </summary>
[DisallowMultipleComponent]
public sealed class EncyclopediaItemRightPage : MonoBehaviour
{
    [Header("Root")]
    [SerializeField] private GameObject pageContentRoot;
    [SerializeField] private GameObject contentRoot;
    [SerializeField] private GameObject emptyRoot;
    [SerializeField] private GameObject undiscoveredRoot;
    [SerializeField] private TMP_Text undiscoveredText;

    [Header("Common Header")]
    [SerializeField] private Image iconImage;
    [SerializeField] private TMP_Text titleText;
    [SerializeField] private RectTransform namePanelRoot;

    [Header("Shared Description")]
    [SerializeField] private GameObject descriptionRoot;
    [SerializeField] private TMP_Text descriptionTitleText;
    [SerializeField] private TMP_Text storyText;

    [SerializeField, HideInInspector] private TMP_Text descriptionText;
    [SerializeField, HideInInspector] private TMP_Text metadataText;
    [SerializeField, HideInInspector] private TMP_Text relicDescriptionText;
    [SerializeField, HideInInspector] private TMP_Text consumableDescriptionText;
    [SerializeField, HideInInspector] private GameObject weaponDetailRoot;
    [SerializeField, HideInInspector] private GameObject relicDetailRoot;
    [SerializeField, HideInInspector] private GameObject consumableDetailRoot;

    [Header("Weapon Sections")]
    [SerializeField] private GameObject weaponStatsRoot;
    [SerializeField] private TMP_Text weaponStatsText;
    [SerializeField] private GameObject weaponAbilityRoot;
    [SerializeField] private Transform abilityContainer;
    [SerializeField] private WeaponAbilityBlockView abilityBlockPrefab;
    [SerializeField] private bool hideTemplateAbilityBlock = true;

    [Header("Weapon Stat / Relic Preview Sections")]
    [SerializeField] private GameObject relicPreviewRoot;
    [SerializeField] private TMP_Text relicLevelText;
    [SerializeField] private GameObject relicPreviewPreviousGuideRoot;
    [SerializeField] private Image relicPreviewPreviousGuideIcon;
    [SerializeField] private CanvasGroup relicPreviewPreviousGuideCanvasGroup;
    [SerializeField] private GameObject relicPreviewNextGuideRoot;
    [SerializeField] private Image relicPreviewNextGuideIcon;
    [SerializeField] private CanvasGroup relicPreviewNextGuideCanvasGroup;
    [SerializeField, Range(0f, 1f)] private float disabledGuideAlpha = 0.35f;
    [SerializeField] private GameObject relicEffectRoot;
    [SerializeField] private TMP_Text relicEffectText;

    [Header("Glossary")]
    [SerializeField] private GlossaryDatabase glossary;
    [SerializeField] private GlossaryPopup glossaryPopup;
    [SerializeField] private TooltipColorPalette tooltipColorPalette;
    [SerializeField] private string glossaryLinkColorHex = "5EC8FF";

    [Header("Scroll")]
    [SerializeField] private ScrollRect detailScrollRect;
    [SerializeField] private bool resetScrollOnBind = true;

    private const string EmptyDescriptionText = "설명 준비 중";
    private const string EmptyRelicEffectText = "효과 정보 없음";

    private readonly List<WeaponAbilityBlockView> abilityBlockPool = new();
    [SerializeField] private WeaponDescriptionHint weaponDescriptionHint = new();
    private WeaponDefinition currentWeapon;
    private bool showDetailedDescription;
    private readonly StringBuilder builder = new();
    private ItemDisplayIconDefaultState iconDefaultState;
    private ItemDetailContext detailContext;
    private Action<string> glossaryClickHandler;
    private int abilityBlockCursor;
    private Coroutine pendingScrollReset;
    private bool tabContentVisible = true;
    private bool interactionEnabled = true;
    private bool localeRefreshPending;
    private RelicDefinition currentRelic;
    private ConsumableDefinition currentConsumable;
    private int relicPreviewLevel = 1;
    private bool warnedMissingHeader;
    private bool warnedMissingDescription;
    private bool warnedMissingAbilityAuthoring;
    private bool warnedMissingScrollRect;

#if UNITY_EDITOR
    private const string AbilityBlockPrefabPath = "Assets/_Project/Prefabs/UI/PopupUI/Encyclopedia/Panel_AbilityBlock_Encyclopedia.prefab";
#endif

    private void Awake()
    {
        InitializeRuntimeState();
        ValidateRequiredReferences();
    }

    private void Update()
    {
        if (!isActiveAndEnabled || !tabContentVisible || !interactionEnabled)
            return;

        // A foreground hover owns this shortcut while it is visible.
        if (currentWeapon != null &&
            (ItemDetailPanel.Instance == null || !ItemDetailPanel.Instance.IsActive) &&
            WeaponDescriptionHint.WasTogglePressed())
        {
            showDetailedDescription = !showDetailedDescription;
            BuildWeaponAbilityBlocks(currentWeapon);
            weaponDescriptionHint.Refresh(true, showDetailedDescription);
            glossaryPopup?.Hide();
            QueueScrollReset();
        }
        if (currentRelic != null)
            HandleRelicPreviewInput(InputBindingService.EnsureInstance());
    }

    private void OnDisable()
    {
        UnityEngine.Localization.Settings.LocalizationSettings.SelectedLocaleChanged -= HandleLocaleChanged;
        CancelPendingScrollReset();
        glossaryPopup?.Hide();
        localeRefreshPending = true;
        showDetailedDescription = false;
    }

    private void OnEnable()
    {
        UnityEngine.Localization.Settings.LocalizationSettings.SelectedLocaleChanged += HandleLocaleChanged;
        if (tabContentVisible && currentWeapon != null)
        {
            BuildWeaponAbilityBlocks(currentWeapon);
            weaponDescriptionHint.Refresh(true, false);
        }
    }

    private void HandleLocaleChanged(UnityEngine.Localization.Locale locale)
    {
        if (!tabContentVisible)
        {
            localeRefreshPending = true;
            return;
        }
        localeRefreshPending = false;
        if (undiscoveredRoot != null && undiscoveredRoot.activeSelf)
            RefreshUndiscoveredText();
        // Refresh the current projection without rebinding selection, preview level or scroll position.
        if (currentWeapon != null)
        {
            ApplyItemHeader(currentWeapon);
            SetDescriptionSection(GameText.Get("code.encyclopediaitemrightpage.a295d44fdf", "스토리"),
                GameText.Asset(currentWeapon, "storyText", currentWeapon.storyText));
            SetText(weaponStatsText, BuildWeaponStatsText(currentWeapon));
            BuildWeaponAbilityBlocks(currentWeapon);
            weaponDescriptionHint.Refresh(true, showDetailedDescription);
        }
        else if (currentRelic != null)
        {
            ApplyItemHeader(currentRelic);
            RefreshRelicPreview();
        }
        else if (currentConsumable != null)
        {
            ApplyItemHeader(currentConsumable);
            SetDescriptionSection(GameText.Get("code.encyclopediaitemrightpage.ce49decb68", "효과"),
                GameText.Asset(currentConsumable, "description", currentConsumable.description));
        }
        RebuildDetailLayout();
    }

#if UNITY_EDITOR
    private void Reset()
    {
        ResolveReferences();
    }

    [ContextMenu("Auto Wire References")]
    private void AutoWireReferences()
    {
        ResolveReferences();
        EditorAuthoringPlayback.MarkDirty(this);
    }
#endif

    public void ResolveReferences()
    {
        if (contentRoot == null || contentRoot == gameObject)
        {
            GameObject resolvedContentRoot = EncyclopediaReferenceResolver.FindGameObject(
                transform,
                "ItemRightContent",
                "ContentRoot",
                "ScrollContent",
                "ViewportContent",
                "Content");
            if (resolvedContentRoot != null && resolvedContentRoot != gameObject)
                contentRoot = resolvedContentRoot;
            else if (contentRoot == null)
                contentRoot = gameObject;
        }

        if (emptyRoot == null)
            emptyRoot = EncyclopediaReferenceResolver.FindGameObject(transform, "EmptyRoot", "EmptyPanel", "EmptyView");

        if (iconImage == null)
            iconImage = EncyclopediaReferenceResolver.FindComponent<Image>(transform, "Icon", "ItemIcon", "DetailIcon", "DetailImage");

        if (titleText == null)
        {
            titleText = EncyclopediaReferenceResolver.FindComponent<TMP_Text>(transform, "TitleText", "NameText", "Name");
            if (titleText == null)
                titleText = EncyclopediaReferenceResolver.FindComponentUnderParent<TMP_Text>(transform, "Name_Panel", "Text", "Text (TMP)", "Text(TMP)");
            if (titleText == null)
                titleText = EncyclopediaReferenceResolver.FindComponentUnderParent<TMP_Text>(transform, "Header", "TitleText", "NameText", "Text", "Text (TMP)", "Text(TMP)");
        }

        if (namePanelRoot == null)
        {
            Transform namePanel = EncyclopediaReferenceResolver.FindTransform(transform, "Name_Panel", "NamePanel", "HeaderNamePanel");
            if (namePanel is RectTransform namePanelRect)
                namePanelRoot = namePanelRect;
            else if (titleText != null)
                namePanelRoot = titleText.transform.parent as RectTransform;
        }

        if (descriptionRoot == null)
            descriptionRoot = EncyclopediaReferenceResolver.FindGameObject(transform, "DescriptionRoot", "DescriptionSection", "CommonDescriptionRoot", "DescriptionPanel");

        Transform descriptionTransform = descriptionRoot != null ? descriptionRoot.transform : null;
        if (descriptionTitleText == null && descriptionTransform != null)
            descriptionTitleText = EncyclopediaReferenceResolver.FindComponent<TMP_Text>(descriptionTransform, "DescriptionTitleText", "SectionTitleText", "TitleText", "Title");

        if (storyText == null)
            storyText = EncyclopediaReferenceResolver.FindComponent<TMP_Text>(transform, "StoryText", "Story");

        if (descriptionText == null && descriptionTransform != null)
            descriptionText = EncyclopediaReferenceResolver.FindComponent<TMP_Text>(descriptionTransform, "DescriptionText", "BodyText");

        if (storyText == null)
            storyText = descriptionText;

        if (descriptionText == null)
            descriptionText = storyText;

        if (weaponStatsRoot == null || weaponStatsRoot == relicPreviewRoot)
        {
            GameObject resolvedWeaponStatsRoot = EncyclopediaReferenceResolver.FindGameObject(
                transform,
                "WeaponStatsRoot",
                "WeaponStatsPanel",
                "WeaponStatsSection",
                "StatTextPanel",
                "StatsRoot",
                "StatRoot");
            if (resolvedWeaponStatsRoot != null && (weaponStatsRoot == null || resolvedWeaponStatsRoot != relicPreviewRoot))
                weaponStatsRoot = resolvedWeaponStatsRoot;
        }

        if (weaponAbilityRoot == null)
            weaponAbilityRoot = EncyclopediaReferenceResolver.FindGameObject(transform, "WeaponAbilityRoot", "AbilityRoot", "AbilitySection", "AbilityContainerRoot");

        Transform abilitySearchRoot = weaponAbilityRoot != null ? weaponAbilityRoot.transform : transform;
        if (abilityContainer == null)
            abilityContainer = EncyclopediaReferenceResolver.FindTransform(abilitySearchRoot, "AbilityContainer", "AbilityBlockContainer");

        if (abilityContainer == null)
            abilityContainer = EncyclopediaReferenceResolver.FindTransform(transform, "AbilityContainer", "AbilityBlockContainer");

        if (abilityBlockPrefab == null && abilityContainer != null)
            abilityBlockPrefab = EncyclopediaReferenceResolver.FindComponent<WeaponAbilityBlockView>(abilityContainer, "Panel_AbilityBlock_Encyclopedia", "Panel_AbilityBlock", "AbilityBlock");

#if UNITY_EDITOR
        if (abilityBlockPrefab == null && !Application.isPlaying)
            abilityBlockPrefab = EditorAuthoringPlayback.LoadAssetAtPath<WeaponAbilityBlockView>(AbilityBlockPrefabPath);
#endif

        if (relicPreviewRoot == null || relicPreviewRoot == weaponStatsRoot)
        {
            GameObject resolvedRelicPreviewRoot = EncyclopediaReferenceResolver.FindGameObject(
                transform,
                "RelicPreviewRoot",
                "RelicLevelPreviewRoot",
                "LevelPreviewRoot",
                "LvPanel",
                "LevelPanel");
            if (resolvedRelicPreviewRoot != null && (relicPreviewRoot == null || resolvedRelicPreviewRoot != weaponStatsRoot))
                relicPreviewRoot = resolvedRelicPreviewRoot;
        }

        if (weaponStatsRoot == null)
            weaponStatsRoot = relicPreviewRoot;
        if (relicPreviewRoot == null)
            relicPreviewRoot = weaponStatsRoot;

        Transform weaponStatsTransform = weaponStatsRoot != null ? weaponStatsRoot.transform : transform;
        if (weaponStatsText == null || weaponStatsText == relicLevelText)
        {
            TMP_Text resolvedWeaponStatsText = EncyclopediaReferenceResolver.FindComponent<TMP_Text>(
                weaponStatsTransform,
                "WeaponStatsText",
                "StatsText",
                "StatText",
                "StatValueText",
                "Text",
                "Text (TMP)",
                "Text(TMP)");
            if (resolvedWeaponStatsText != null && (weaponStatsText == null || resolvedWeaponStatsText != relicLevelText))
                weaponStatsText = resolvedWeaponStatsText;
        }

        Transform relicPreviewTransform = relicPreviewRoot != null ? relicPreviewRoot.transform : transform;
        if (relicLevelText == null || relicLevelText == weaponStatsText)
        {
            TMP_Text resolvedRelicLevelText = EncyclopediaReferenceResolver.FindComponent<TMP_Text>(
                relicPreviewTransform,
                "LvTxt",
                "LvText",
                "LevelText",
                "RelicLevelText",
                "PreviewLevelText");
            if (resolvedRelicLevelText != null && (relicLevelText == null || resolvedRelicLevelText != weaponStatsText))
                relicLevelText = resolvedRelicLevelText;
        }

        ResolveRelicPreviewGuideReferences(relicPreviewTransform);

        if (relicEffectRoot == null)
            relicEffectRoot = EncyclopediaReferenceResolver.FindGameObject(transform, "RelicEffectRoot", "EffectRoot", "RelicEffectSection");

        Transform relicEffectTransform = relicEffectRoot != null ? relicEffectRoot.transform : null;
        if (relicEffectText == null && relicEffectTransform != null)
            relicEffectText = EncyclopediaReferenceResolver.FindComponent<TMP_Text>(relicEffectTransform, "RelicEffectText", "EffectText", "BodyText", "DescriptionText", "Text", "Text (TMP)", "Text(TMP)");

        if (glossaryPopup == null)
            glossaryPopup = GetComponentInChildren<GlossaryPopup>(true);

        if (detailScrollRect == null)
            detailScrollRect = GetComponent<ScrollRect>() ?? GetComponentInChildren<ScrollRect>(true);

        if (pageContentRoot == null && detailScrollRect != null)
            pageContentRoot = detailScrollRect.gameObject;

        if (detailScrollRect != null && detailScrollRect.content == null && contentRoot != null)
        {
            RectTransform contentRect = contentRoot.transform as RectTransform;
            if (contentRect != null && contentRect != detailScrollRect.transform)
                detailScrollRect.content = contentRect;
        }

        if (iconImage != null)
            iconDefaultState = new ItemDisplayIconDefaultState(iconImage);

        InitializeRuntimeState();
    }

    private void InitializeRuntimeState()
    {
        if (iconImage != null)
            iconDefaultState = new ItemDisplayIconDefaultState(iconImage);

        detailContext ??= new ItemDetailContext();
        glossaryClickHandler ??= ShowGlossaryPopup;
    }

    private void ValidateRequiredReferences()
    {
        if (titleText == null && !warnedMissingHeader)
        {
            warnedMissingHeader = true;
            CapstoneDiagnostics.EditorOnlyLog.LogWarning("[EncyclopediaItemRightPage] TitleText is not assigned. Item name cannot be displayed.", this);
        }

        if (storyText == null && !warnedMissingDescription)
        {
            warnedMissingDescription = true;
            CapstoneDiagnostics.EditorOnlyLog.LogWarning("[EncyclopediaItemRightPage] StoryText is not assigned. Item description cannot be displayed.", this);
        }

        if (detailScrollRect == null && !warnedMissingScrollRect)
        {
            warnedMissingScrollRect = true;
            CapstoneDiagnostics.EditorOnlyLog.LogWarning("[EncyclopediaItemRightPage] ScrollRect is not assigned. Long item details will not auto-reset scroll position.", this);
        }
    }

    private void ValidateWeaponAuthoring()
    {
        if ((abilityContainer == null || abilityBlockPrefab == null) && !warnedMissingAbilityAuthoring)
        {
            warnedMissingAbilityAuthoring = true;
            CapstoneDiagnostics.EditorOnlyLog.LogWarning("[EncyclopediaItemRightPage] AbilityContainer or ability block prefab is not assigned. Weapon skills cannot be displayed.", this);
        }
    }

    public void SetInteractionEnabled(bool enabled)
    {
        interactionEnabled = enabled;
    }

    public void SetContentVisible(bool visible)
    {
        tabContentVisible = visible;
        if (pageContentRoot != null)
            pageContentRoot.SetActive(visible);
        if (visible && localeRefreshPending)
            HandleLocaleChanged(UnityEngine.Localization.Settings.LocalizationSettings.SelectedLocale);
        if (!visible)
        {
            CancelPendingScrollReset();
            detailScrollRect?.StopMovement();
            glossaryPopup?.Hide();
        }
    }

    public void SettleLayout()
    {
        RebuildDetailLayout();
    }

    public void SettleLayoutAndResetScroll()
    {
        CancelPendingScrollReset();
        if (!resetScrollOnBind)
        {
            RebuildDetailLayout();
            return;
        }

        ApplyScrollReset();
    }

    public void Clear()
    {
        InitializeRuntimeState();
        currentRelic = null;
        currentWeapon = null;
        currentConsumable = null;
        relicPreviewLevel = 1;
        SetVisible(false);
        SetText(titleText, string.Empty);
        SetText(descriptionTitleText, string.Empty);
        SetText(storyText, string.Empty);
        SetText(weaponStatsText, string.Empty);
        SetText(relicLevelText, string.Empty);
        SetText(relicEffectText, string.Empty);
        ItemDisplayIconUtility.Clear(iconImage, iconDefaultState);
        HideTypeSections();
        HideAbilityBlocks();
        RebuildHeaderLayout();
        glossaryPopup?.Hide();
        QueueScrollReset();
    }

    public void ShowUndiscovered(ScriptableObject item)
    {
        Clear();
        SetStorySectionVisible(false);
        SetActive(emptyRoot, false);
        SetActive(undiscoveredRoot, true);
        RefreshUndiscoveredText();
    }

    private void RefreshUndiscoveredText() => SetText(undiscoveredText,
        GameText.Get("encyclopedia.item_not_acquired", "아직 획득하지 못한 아이템입니다."));

    public void ShowWeapon(WeaponDefinition weapon)
    {
        InitializeRuntimeState();
        ValidateRequiredReferences();
        ValidateWeaponAuthoring();
        if (weapon == null)
        {
            Clear();
            return;
        }

        currentRelic = null;
        relicPreviewLevel = 1;
        SetVisible(true);
        HideTypeSections();
        currentWeapon = weapon;
        currentConsumable = null;
        weaponDescriptionHint.Refresh(true, false);
        ApplyItemHeader(weapon);
        SetDescriptionSection(GameText.Get("code.encyclopediaitemrightpage.a295d44fdf", "스토리"), GameText.Asset(weapon, "storyText", weapon.storyText));

        string statsText = BuildWeaponStatsText(weapon);
        SetText(weaponStatsText, statsText);
        SetActive(weaponStatsRoot, !string.IsNullOrWhiteSpace(statsText));
        SetRelicPreviewGuidesVisible(false);

        SetActive(weaponAbilityRoot, true);
        int abilityCount = BuildWeaponAbilityBlocks(weapon);
        SetActive(weaponAbilityRoot, abilityCount > 0);

        QueueScrollReset();
    }

    public void ShowRelic(RelicDefinition relic)
    {
        InitializeRuntimeState();
        ValidateRequiredReferences();
        if (relic == null)
        {
            Clear();
            return;
        }

        SetVisible(true);
        HideTypeSections();
        HideAbilityBlocks();
        currentRelic = relic;
        currentWeapon = null;
        currentConsumable = null;
        relicPreviewLevel = 1;

        ApplyItemHeader(relic);
        SetStorySectionVisible(false);
        SetActive(relicPreviewRoot, true);
        RefreshRelicPreview();
        QueueScrollReset();
    }

    public void ShowConsumable(ConsumableDefinition consumable)
    {
        InitializeRuntimeState();
        ValidateRequiredReferences();
        if (consumable == null)
        {
            Clear();
            return;
        }

        currentRelic = null;
        currentWeapon = null;
        currentConsumable = consumable;
        relicPreviewLevel = 1;
        SetVisible(true);
        HideTypeSections();
        HideAbilityBlocks();
        ApplyItemHeader(consumable);
        SetDescriptionSection(GameText.Get("code.encyclopediaitemrightpage.ce49decb68", "효과"), GameText.Asset(consumable, "description", consumable.description));
        QueueScrollReset();
    }

    private void ApplyItemHeader(ScriptableObject item)
    {
        if (iconImage != null) iconImage.color = Color.white;
        if (item != null)
            ItemDisplayIconUtility.Apply(iconImage, item, ItemDisplayIconContext.InventorySlot, iconDefaultState);
        else
            ItemDisplayIconUtility.Clear(iconImage, iconDefaultState);

        SetText(titleText, GetItemDisplayName(item));
        RebuildHeaderLayout();
        glossaryPopup?.Hide();
    }

    private void SetDescriptionSection(string title, string rawDescription)
    {
        string description = FormatTextOrFallback(rawDescription, GameText.Get("encyclopedia.description_pending", EmptyDescriptionText));
        SetActive(descriptionRoot, true);
        SetActive(descriptionTitleText != null ? descriptionTitleText.gameObject : null, true);
        SetActive(storyText != null ? storyText.gameObject : null, true);
        SetText(descriptionTitleText, title);
        SetText(storyText, description);
    }

    private int BuildWeaponAbilityBlocks(WeaponDefinition weapon)
    {
        HideAbilityBlocks();
        abilityBlockCursor = 0;
        ConfigureAbilityContainerLayoutForBlocks();

        if (weapon == null)
            return 0;

        int count = 0;
        if (weapon.weaponId == "Weapon.CrimsonBoundary" &&
            AddAbilityBlock(GameText.Get("code.encyclopediaitemrightpage.065f292f33", "기본 공격"), weapon.GetAbility(WeaponAbilitySlot.Attack), weapon.attackInputHint, InputActionId.PrimaryAttack))
            count++;
        if (AddAbilityBlock(GameText.Get("code.encyclopediaitemrightpage.a091200702", "스킬 1"), weapon.GetAbility(WeaponAbilitySlot.Skill1), weapon.skill1InputHint, InputActionId.Skill1))
            count++;
        if (AddAbilityBlock(GameText.Get("code.encyclopediaitemrightpage.01d28c5504", "스킬 2"), weapon.GetAbility(WeaponAbilitySlot.Skill2), weapon.skill2InputHint, InputActionId.Skill2))
            count++;



        RebuildDetailLayout();
        return count;
    }

    private bool AddAbilityBlock(string header, AbilityDefinition ability, string inputHint, InputActionId? inputAction)
    {
        if (abilityContainer == null || abilityBlockPrefab == null || ability == null)
            return false;

        List<AbilityDisplayState> displayStates = BuildAbilityDisplayStates(ability, header, inputHint);
        if (displayStates.Count == 0)
            return false;

        foreach (AbilityDisplayState state in displayStates)
        {
            WeaponAbilityBlockView view = GetAbilityBlock();
            if (view == null)
                continue;
            view.Set(state.Title, state.Icon, state.InputHint, state.CooldownSeconds,
                state.ExtraMeta, state.Body, inputAction, glossaryClickHandler);
        }
        return true;
    }

    private WeaponAbilityBlockView GetAbilityBlock()
    {
        if (abilityBlockPrefab == null || abilityContainer == null)
            return null;

        if (hideTemplateAbilityBlock && abilityBlockPrefab.transform.IsChildOf(abilityContainer))
            abilityBlockPrefab.gameObject.SetActive(false);

        while (abilityBlockCursor < abilityBlockPool.Count && abilityBlockPool[abilityBlockCursor] == null)
            abilityBlockCursor++;

        WeaponAbilityBlockView view;
        if (abilityBlockCursor < abilityBlockPool.Count)
        {
            view = abilityBlockPool[abilityBlockCursor];
        }
        else
        {
            view = Instantiate(abilityBlockPrefab, abilityContainer);
            abilityBlockPool.Add(view);
        }

        abilityBlockCursor++;
        view.ResetPooledPresentationState();
        view.gameObject.SetActive(true);
        return view;
    }

    private void ConfigureAbilityContainerLayoutForBlocks()
    {
        if (abilityContainer == null)
            return;

        if (abilityContainer.TryGetComponent(out VerticalLayoutGroup verticalLayout))
        {
            verticalLayout.childControlWidth = true;
            verticalLayout.childControlHeight = true;
            verticalLayout.childForceExpandWidth = true;
            verticalLayout.childForceExpandHeight = false;
        }
    }

    private void HideAbilityBlocks()
    {
        abilityBlockCursor = 0;

        for (int i = 0; i < abilityBlockPool.Count; i++)
        {
            WeaponAbilityBlockView view = abilityBlockPool[i];
            if (view == null)
                continue;

            view.ResetPooledPresentationState();
            view.gameObject.SetActive(false);
        }

        if (hideTemplateAbilityBlock && abilityBlockPrefab != null && abilityContainer != null && abilityBlockPrefab.transform.IsChildOf(abilityContainer))
            abilityBlockPrefab.gameObject.SetActive(false);
    }

    private List<AbilityDisplayState> BuildAbilityDisplayStates(AbilityDefinition ability, string header, string inputHint)
    {
        var states = new List<AbilityDisplayState>();
        if (ability == null)
            return states;

        if (ability.sourceObject is IAbilityTooltipVariantProvider variantProvider)
        {
            int count = Mathf.Max(0, variantProvider.GetAbilityTooltipVariantCount(ability, detailContext));
            for (int i = 0; i < count; i++)
            {
                AbilityTooltipVariant variant = variantProvider.BuildAbilityTooltipVariant(ability, i, detailContext);
                states.Add(BuildDisplayState(ability, variant, header, inputHint));
            }
        }

        if (states.Count == 0)
            states.Add(BuildDefaultDisplayState(ability, header, inputHint));

        return states;
    }

    private AbilityDisplayState BuildDisplayState(AbilityDefinition ability, AbilityTooltipVariant variant, string header, string inputHint)
    {
        string title = !string.IsNullOrWhiteSpace(variant.Title)
            ? variant.Title
            : (!string.IsNullOrWhiteSpace(ability.DisplayName) ? ability.DisplayName : header);

        Sprite icon = variant.Icon != null ? variant.Icon : ability.icon;
        string body = !showDetailedDescription && !string.IsNullOrWhiteSpace(variant.SimpleBody)
            ? variant.SimpleBody
            : (!string.IsNullOrWhiteSpace(variant.Body) ? variant.Body : BuildAbilityBody(ability));
        string resolvedInputHint = !string.IsNullOrWhiteSpace(variant.InputHint) ? variant.InputHint : inputHint;
        string extraMeta = !string.IsNullOrWhiteSpace(variant.ExtraMeta) ? variant.ExtraMeta : "-";

        return new AbilityDisplayState(
            title,
            icon,
            resolvedInputHint,
            variant.CooldownSeconds ?? ability.cooldown,
            extraMeta,
            FormatText(body));
    }

    private AbilityDisplayState BuildDefaultDisplayState(AbilityDefinition ability, string header, string inputHint)
    {
        string title = !string.IsNullOrWhiteSpace(ability.DisplayName) ? ability.DisplayName : header;
        return new AbilityDisplayState(
            title,
            ability.icon,
            inputHint,
            ability.cooldown,
            "-",
            FormatText(BuildAbilityBody(ability)));
    }

    private string BuildAbilityBody(AbilityDefinition ability)
    {
        if (!showDetailedDescription && ability != null && !string.IsNullOrWhiteSpace(ability.SimpleDescription))
            return ability.SimpleDescription;

        builder.Clear();

        if (ability != null && !string.IsNullOrWhiteSpace(ability.Description))
            builder.AppendLine(ability.Description);

        if (ability != null && ability.sourceObject is IDetailProvider provider)
        {
            ItemDetailBlock block = provider.BuildDetailBlock(detailContext);
            if (!string.IsNullOrWhiteSpace(block.body))
            {
                if (builder.Length > 0)
                    builder.AppendLine();

                builder.AppendLine(block.body);
            }
        }

        return builder.ToString().TrimEnd();
    }

    private void HandleRelicPreviewInput(InputBindingService input)
    {
        if (currentRelic == null || input == null)
            return;

        int nextLevel = relicPreviewLevel;
        if (input.WasPressedThisFrame(InputContextShortcutId.RelicPreviewPrevious))
            nextLevel--;
        if (input.WasPressedThisFrame(InputContextShortcutId.RelicPreviewNext))
            nextLevel++;

        int maxLevel = Mathf.Max(1, currentRelic.maxLevel);
        nextLevel = Mathf.Clamp(nextLevel, 1, maxLevel);
        if (nextLevel == relicPreviewLevel)
            return;

        relicPreviewLevel = nextLevel;
        RefreshRelicPreview();
    }

    private void RefreshRelicPreview()
    {
        if (currentRelic == null)
            return;

        int maxLevel = Mathf.Max(1, currentRelic.maxLevel);
        relicPreviewLevel = Mathf.Clamp(relicPreviewLevel, 1, maxLevel);
        string effectText = FormatText(BuildRelicEffectText(currentRelic, relicPreviewLevel));
        SetText(relicLevelText, $"Lv {relicPreviewLevel} / {maxLevel}");
        SetRelicEffectSection(effectText);

        RefreshRelicPreviewGuides(maxLevel);
        RebuildDetailLayout();
    }

    private string BuildRelicEffectText(RelicDefinition relic, int previewLevel)
    {
        if (relic == null || relic.logic == null)
            return GameText.Get("encyclopedia.effect_missing", EmptyRelicEffectText);

        RelicTooltipData tooltip = relic.logic.BuildTooltip(relic, previewLevel, detailContext);
        return tooltip != null && !string.IsNullOrWhiteSpace(tooltip.effectText)
            ? tooltip.effectText
            : GameText.Get("encyclopedia.effect_missing", EmptyRelicEffectText);
    }

    private void RefreshRelicPreviewGuides(int maxLevel)
    {
        InputBindingService input = InputBindingService.EnsureInstance();
        ApplyRelicPreviewGuide(
            relicPreviewPreviousGuideRoot,
            relicPreviewPreviousGuideIcon,
            relicPreviewPreviousGuideCanvasGroup,
            input.GetContextShortcutGlyph(InputContextShortcutId.RelicPreviewPrevious),
            true,
            relicPreviewLevel > 1);
        ApplyRelicPreviewGuide(
            relicPreviewNextGuideRoot,
            relicPreviewNextGuideIcon,
            relicPreviewNextGuideCanvasGroup,
            input.GetContextShortcutGlyph(InputContextShortcutId.RelicPreviewNext),
            true,
            relicPreviewLevel < maxLevel);
    }

    private void ResolveRelicPreviewGuideReferences(Transform relicPreviewTransform)
    {
        if (relicPreviewPreviousGuideRoot == null)
            relicPreviewPreviousGuideRoot = EncyclopediaReferenceResolver.FindGameObject(relicPreviewTransform, "RelicPreviewPreviousGuide", "PreviousGuide", "PrevGuide", "PrevPreview");
        if (relicPreviewNextGuideRoot == null)
            relicPreviewNextGuideRoot = EncyclopediaReferenceResolver.FindGameObject(relicPreviewTransform, "RelicPreviewNextGuide", "NextGuide", "NextPreview");

        if (relicPreviewPreviousGuideIcon == null && relicPreviewPreviousGuideRoot != null)
            relicPreviewPreviousGuideIcon = ResolveGuideIcon(relicPreviewPreviousGuideRoot.transform);
        if (relicPreviewNextGuideIcon == null && relicPreviewNextGuideRoot != null)
            relicPreviewNextGuideIcon = ResolveGuideIcon(relicPreviewNextGuideRoot.transform);

        if (relicPreviewPreviousGuideCanvasGroup == null && relicPreviewPreviousGuideRoot != null)
            relicPreviewPreviousGuideCanvasGroup = relicPreviewPreviousGuideRoot.GetComponent<CanvasGroup>();
        if (relicPreviewNextGuideCanvasGroup == null && relicPreviewNextGuideRoot != null)
            relicPreviewNextGuideCanvasGroup = relicPreviewNextGuideRoot.GetComponent<CanvasGroup>();
    }

    private void ShowGlossaryPopup(string key)
    {
        if (glossaryPopup == null)
            return;

        if (glossary != null && glossary.TryGet(key, out string description))
            glossaryPopup.Show(key, description);
        else
            glossaryPopup.Show(key, GameText.Get("encyclopedia.description_pending", EmptyDescriptionText));
    }

    private static Image ResolveGuideIcon(Transform guideRoot)
    {
        if (guideRoot == null)
            return null;

        Image childIcon = EncyclopediaReferenceResolver.FindComponent<Image>(guideRoot, "Icon", "GuideIcon");
        return childIcon != null ? childIcon : guideRoot.GetComponent<Image>();
    }

    private void SetVisible(bool visible)
    {
        SetActive(undiscoveredRoot, false);
        SetActive(detailScrollRect != null ? detailScrollRect.gameObject : null, visible);
        SetActive(contentRoot, visible);
        SetActive(emptyRoot, !visible);
    }

    private void HideTypeSections()
    {
        currentWeapon = null;
        showDetailedDescription = false;
        weaponDescriptionHint.Refresh(false, false);
        SetActive(weaponStatsRoot, false);
        SetActive(weaponAbilityRoot, false);
        SetActive(relicPreviewRoot, false);
        SetActive(relicEffectRoot, false);
        SetActive(relicEffectText != null ? relicEffectText.gameObject : null, false);
        SetRelicPreviewGuidesVisible(false);
        SetText(weaponStatsText, string.Empty);
        SetText(relicLevelText, string.Empty);
        SetText(relicEffectText, string.Empty);
    }

    private void SetRelicPreviewGuidesVisible(bool visible)
    {
        SetActive(relicPreviewPreviousGuideRoot, visible);
        SetActive(relicPreviewNextGuideRoot, visible);
    }

    private void SetStorySectionVisible(bool visible)
    {
        SetActive(descriptionRoot, visible);
        SetActive(descriptionTitleText != null ? descriptionTitleText.gameObject : null, visible);
        SetActive(storyText != null ? storyText.gameObject : null, visible);
        if (!visible)
        {
            SetText(descriptionTitleText, string.Empty);
            SetText(storyText, string.Empty);
        }
    }

    private void SetRelicEffectSection(string effectText)
    {
        bool hasDedicatedEffectText = relicEffectText != null && relicEffectText != storyText;
        SetActive(relicEffectRoot, hasDedicatedEffectText);
        SetActive(relicEffectText != null ? relicEffectText.gameObject : null, hasDedicatedEffectText);
        if (hasDedicatedEffectText)
            SetText(relicEffectText, effectText);
    }

    private void QueueScrollReset()
    {
        CancelPendingScrollReset();

        if (!tabContentVisible)
            return;

        if (!resetScrollOnBind)
        {
            RebuildDetailLayout();
            return;
        }

        ApplyScrollReset();
    }

    private void CancelPendingScrollReset()
    {
        if (pendingScrollReset == null)
            return;

        StopCoroutine(pendingScrollReset);
        pendingScrollReset = null;
    }

    private void ApplyScrollReset()
    {
        RebuildDetailLayout();

        if (detailScrollRect == null)
            return;

        detailScrollRect.StopMovement();
        if (detailScrollRect.vertical)
            detailScrollRect.verticalNormalizedPosition = 1f;
        if (detailScrollRect.horizontal)
            detailScrollRect.horizontalNormalizedPosition = 0f;
    }

    private void RebuildDetailLayout()
    {
        ForceDetailTextMeshes();
        Canvas.ForceUpdateCanvases();

        RebuildHeaderLayout();

        if (abilityContainer is RectTransform abilityRect)
            LayoutRebuilder.ForceRebuildLayoutImmediate(abilityRect);

        if (contentRoot != null && contentRoot.transform is RectTransform contentRootRect)
            LayoutRebuilder.ForceRebuildLayoutImmediate(contentRootRect);

        if (detailScrollRect != null)
        {
            if (detailScrollRect.content != null)
                LayoutRebuilder.ForceRebuildLayoutImmediate(detailScrollRect.content);

            if (detailScrollRect.viewport != null)
                LayoutRebuilder.ForceRebuildLayoutImmediate(detailScrollRect.viewport);
        }

        Canvas.ForceUpdateCanvases();
    }

    private void ForceDetailTextMeshes()
    {
        ForceTextMeshUpdate(descriptionTitleText);
        ForceTextMeshUpdate(storyText);
        ForceTextMeshUpdate(weaponStatsText);
        ForceTextMeshUpdate(relicLevelText);
        ForceTextMeshUpdate(relicEffectText);
    }

    private void RebuildHeaderLayout()
    {
        if (titleText != null)
        {
            titleText.ForceMeshUpdate();
            LayoutRebuilder.ForceRebuildLayoutImmediate(titleText.rectTransform);
        }

        if (namePanelRoot != null)
            LayoutRebuilder.ForceRebuildLayoutImmediate(namePanelRoot);
    }

    private static void ForceTextMeshUpdate(TMP_Text text)
    {
        if (text != null && text.gameObject.activeInHierarchy)
            text.ForceMeshUpdate();
    }

    private string FormatText(string raw)
    {
        return DetailTextFormatter.Format(raw ?? string.Empty, tooltipColorPalette, glossaryLinkColorHex);
    }

    private string FormatTextOrFallback(string raw, string fallback)
    {
        return FormatText(string.IsNullOrWhiteSpace(raw) ? fallback : raw);
    }

    private string BuildWeaponStatsText(WeaponDefinition weapon)
    {
        if (weapon == null || weapon.statModifiers == null || weapon.statModifiers.Count == 0)
            return string.Empty;

        builder.Clear();
        for (int i = 0; i < weapon.statModifiers.Count; i++)
        {
            WeaponDefinition.WeaponStatModifier modifier = weapon.statModifiers[i];
            if (modifier.attribute == null)
                continue;

            string label = !string.IsNullOrWhiteSpace(modifier.labelOverride)
                ? GameText.Asset(weapon, $"statModifiers.Array.data[{i}].labelOverride", modifier.labelOverride)
                : ResolveAttributeName(modifier.attribute);
            string value = modifier.type == ModifierType.Percent
                ? FormatTooltipValue(modifier.value, true)
                : FormatTooltipValue(modifier.value, false);

            if (builder.Length > 0)
                builder.AppendLine();

            builder.Append(label).Append(' ').Append(value);
        }

        return builder.ToString();
    }

    private static string FormatTooltipValue(float value, bool isPercent)
    {
        string sign = value > 0f ? "+" : string.Empty;
        float displayValue = isPercent ? value * 100f : value;
        string suffix = isPercent ? "%" : string.Empty;
        return $"[{sign}{displayValue:0.##}{suffix}]";
    }

    private static string ResolveAttributeName(AttributeDefinition attribute)
    {
        if (attribute == null)
            return string.Empty;

        if (!string.IsNullOrWhiteSpace(attribute.DisplayName))
            return attribute.DisplayName;

        return attribute.name;
    }

    private static string GetItemDisplayName(ScriptableObject item)
    {
        if (item is IInventoryItemDefinition definition && !string.IsNullOrWhiteSpace(definition.DisplayName))
            return definition.DisplayName;

        return item != null ? item.name : string.Empty;
    }

    private void ApplyRelicPreviewGuide(GameObject root, Image icon, CanvasGroup canvasGroup, InputGlyphPresentation glyph, bool visible, bool enabled)
    {
        SetActive(root, visible);
        if (icon != null)
        {
            if (glyph.HasIcon)
            {
                icon.sprite = glyph.Icon;
                icon.enabled = true;
            }
            else
            {
                icon.enabled = icon.sprite != null;
            }
        }

        if (canvasGroup == null)
            return;

        canvasGroup.alpha = enabled ? 1f : disabledGuideAlpha;
        canvasGroup.interactable = false;
        canvasGroup.blocksRaycasts = false;
    }

    private static void SetText(TMP_Text text, string value)
    {
        if (text != null)
            text.text = value ?? string.Empty;
    }

    private static void SetActive(GameObject target, bool active)
    {
        if (target != null)
            target.SetActive(active);
    }

    /// <summary>
    /// 책임 : 무기 능력 블록에 표시할 제목, 아이콘, 입력, 쿨다운, 설명 상태를 묶는다.
    /// </summary>
    private readonly struct AbilityDisplayState
    {
        public AbilityDisplayState(string title, Sprite icon, string inputHint, float cooldownSeconds, string extraMeta, string body)
        {
            Title = title;
            Icon = icon;
            InputHint = inputHint;
            CooldownSeconds = cooldownSeconds;
            ExtraMeta = extraMeta;
            Body = body;
        }

        public string Title { get; }
        public Sprite Icon { get; }
        public string InputHint { get; }
        public float CooldownSeconds { get; }
        public string ExtraMeta { get; }
        public string Body { get; }
    }

}
