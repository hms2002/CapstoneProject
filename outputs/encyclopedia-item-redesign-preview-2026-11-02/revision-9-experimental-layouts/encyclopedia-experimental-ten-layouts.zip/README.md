# 아이템 도감 — 실험적인 정보 배치 10안 (revision 9)

## 작업 범위

작업 모드: Implementation — Aseprite 승인 견본 제작. 사용자는 기존 10안보다 더 실험적인 레이아웃을 요청했다. 이번에는 공통 팔레트와 책 외형을 유지하면서 목록 위치, 양쪽 페이지의 정보 분배와 읽는 방향을 바꿨다.

- 좌우 페이지는 원본 1920×1080 캔버스 기준 각각 460×576이며 X=464 / 996, Y=286이다. 중앙 72픽셀 접힘선은 보존했다.
- 무기 능력치와 유물 레벨은 별도 영역으로 유지했다.
- 기존 이름·스토리·스탯·기술·입력·쿨타임·유물 효과·레벨·상세 단축키를 생략하지 않았다. 문구는 새 너비에 맞춰 재배치·줄바꿈했다.
- 기존 글자색 역할, Galmuri9, 프로젝트의 아이템·스킬 이미지와 밝은 종이를 사용했다. 좁은 두 열의 기술명은 18px, 일반 기술명은 27px, 본문은 18px/23px 행간이다.
- Unity 적용은 포함하지 않는다.

## 새 배치

| 번호 | 이름 | 구성 | 무기·유물 비교 | 개별 이미지 | Aseprite |
|---|---|---|---|---|---|
| 11 | 장비와 기술 | 왼쪽은 장비 기록 · 오른쪽은 기술 전용 | [비교](11-pair.png) | [무기](11-weapon.png) · [유물](11-relic.png) | [무기](11-weapon.aseprite) · [유물](11-relic.aseprite) · [비교판](11-pair.aseprite) |
| 12 | 역방향 서가 | 왼쪽 설명 · 오른쪽 아이템 선택 | [비교](12-pair.png) | [무기](12-weapon.png) · [유물](12-relic.png) | [무기](12-weapon.aseprite) · [유물](12-relic.aseprite) · [비교판](12-pair.aseprite) |
| 13 | 하단 양면 서랍 | 두 페이지 하단에 목록 · 본문은 양쪽에 | [비교](13-pair.png) | [무기](13-weapon.png) · [유물](13-relic.png) | [무기](13-weapon.aseprite) · [유물](13-relic.aseprite) · [비교판](13-pair.aseprite) |
| 14 | 상단 목차와 분단 | 상단 목록 · 오른쪽 두 열 기술 | [비교](14-pair.png) | [무기](14-weapon.png) · [유물](14-relic.png) | [무기](14-weapon.aseprite) · [유물](14-relic.aseprite) · [비교판](14-pair.aseprite) |
| 15 | 중앙 색인 | 접힘선 양옆에 목록 · 설명은 바깥쪽 | [비교](15-pair.png) | [무기](15-weapon.png) · [유물](15-relic.png) | [무기](15-weapon.aseprite) · [유물](15-relic.aseprite) · [비교판](15-pair.aseprite) |
| 16 | 양면 대조표 | 이름·입력은 왼쪽 · 같은 행의 설명은 오른쪽 | [비교](16-pair.png) | [무기](16-weapon.png) · [유물](16-relic.png) | [무기](16-weapon.aseprite) · [유물](16-relic.aseprite) · [비교판](16-pair.aseprite) |
| 17 | 둘레 진열 | 선택 아이템 주위로 목록 배치 | [비교](17-pair.png) | [무기](17-weapon.png) · [유물](17-relic.png) | [무기](17-weapon.aseprite) · [유물](17-relic.aseprite) · [비교판](17-pair.aseprite) |
| 18 | 대각선 기록 | 왼쪽 장비·첫 기술 · 오른쪽 목록·후속 기술 | [비교](18-pair.png) | [무기](18-weapon.png) · [유물](18-relic.png) | [무기](18-weapon.aseprite) · [유물](18-relic.aseprite) · [비교판](18-pair.aseprite) |
| 19 | 기술 신문 | 왼쪽 두 열 기술 · 오른쪽 장비·끝 기술 | [비교](19-pair.png) | [무기](19-weapon.png) · [유물](19-relic.png) | [무기](19-weapon.aseprite) · [유물](19-relic.aseprite) · [비교판](19-pair.aseprite) |
| 20 | 상하 분단 | 오른쪽 위는 두 열 · 아래는 한 열 | [비교](20-pair.png) | [무기](20-weapon.png) · [유물](20-relic.png) | [무기](20-weapon.aseprite) · [유물](20-relic.aseprite) · [비교판](20-pair.aseprite) |

11/12는 장비 기록과 기술을 한 페이지씩 맡기되 방향을 반전했다. 13/14는 목록을 양쪽 하단/상단으로 옮겼다. 15는 중앙 접힘선 양옆의 안쪽 여백에 목록을 나눴다. 16은 번호와 가로 구분선을 맞춰 기술 이름/입력과 설명을 두 페이지에서 대조한다. 17은 아이템 주위를 둘러 목록을 놓았다. 18은 장비와 목록을 대각선으로 분배했다. 19는 왼쪽 두 열에 기술을, 오른쪽에 장비와 마지막 기술을 놓았다. 20은 오른쪽 위 두 열과 아래 한 열을 결합했다.

16은 시선 이동이 늘고, 14/19/20은 열이 좁아 줄바꿈이 늘어난다. 13/14/15의 양면 목록은 선택 순서와 게임패드 탐색 규칙을 적용 단계에서 정해야 한다. 이들은 비교를 위한 디자인 선택지이며 해당 조작을 구현한 상태가 아니다.

## 파일

- [11–12](compare-11-12.png), [13–14](compare-13-14.png), [15–16](compare-15-16.png), [17–18](compare-17-18.png), [19–20](compare-19-20.png)
- [전체 PNG·Aseprite ZIP](encyclopedia-experimental-ten-layouts.zip)
- [배치 노드](layout.json), [글자 줄바꿈 위치](text-layout.json), [안별 구성](options.json), [전체 샘플 문구](content-spec.json)
- [이전 10안](../revision-8-ten-options/README.md)

개별 견본 1260×760, 무기·유물 비교판 2520×850, 두 안씩 묶은 비교판 2520×1700. 원본 Aseprite는 책 / UI 도형 / 기존 게임 이미지 / 글자 레이어를 분리했다. 글자는 픽셀 레이어이며 라이브 텍스트가 아니다.

## 정보와 제작

무기는 뇌창 갈라론의 이름, 전기 +5, 전체 스토리, 기본 스킬 두 분기와 낙뢰 표식, Mouse1/Mouse1/Q, 3s/3s/10s, 전체 간단 설명을 포함한다. 유물은 쇳덩이의 예비 탄창, Lv. 2/3, Q/E, 여섯 효과 문단과 남은 장전 횟수 문단을 포함한다. 분단·대조표 안에서도 원래 문장은 모두 남겼다.

목록 순서·획득 상태·페이지 수는 견본용 예시이며 실제 저장 데이터와 연동하지 않았다. 미획득 항목의 검은 실루엣과 상세 숨김은 추후 게임 적용에서 계속 유지할 조건이다.

글자 레이어는 프로젝트 Galmuri9를 단색 픽셀 방식으로 렌더링했다. 의미 강조 색과 얇은 불투명 외곽선을 유지했다. 도형·아이콘 합성 및 최종 PNG/aseprite 저장은 네이티브 Aseprite로 수행했다.

## 확인과 남은 사항

10개 무기·유물 비교판과 일부 개별 원본을 시각적으로 검토했다. 본문 배치에는 잘라내기나 말줄임을 사용하지 않았고, 새 레이어는 동일 크기의 두 페이지 경계 안에 배치했다. 임시 제작 스크립트는 삭제했으며 일회용 실행 도구를 저장소에 추가하지 않았다.

자동 테스트, Unity PlayMode 확인, 컴파일·임포트는 실행하지 않았다. Assets, 씬, 프리팹, ProjectSettings는 변경하지 않았다. 최종 디자인 선택, 실제 TMP 표현, 더 긴 상세/다국어 문구의 스크롤, 여러 페이지에 걸친 선택/포커스 동작은 적용 단계에 남는다.

문서 영향: [SessionLog](../../../Docs/SessionLogs/2026-11-02.md). 기존 동일 페이지·영역 분리 결정을 유지하며 DecisionLog·ErrorLog·StructureMemory·Presentation HTML은 변경하지 않았다. Presentation HTML stale candidate 없음.

